﻿Imports System.Text
Imports System.Net
Imports System.Text.RegularExpressions
Imports System.Security.Cryptography

Public Class DynuCom
    Dim myip As String = GetMyIP()
    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dynuapi As String = "http://api.dynu.com/nic/update?username=" & TextBox2.Text & "&password=" & md5hash() & "&mydomain=" & TextBox1.Text & "&myip=" & myip
        Dim wc = New Net.WebClient()
        Dim utf8 = New UTF8Encoding
        Dim page As String = utf8.GetString(wc.DownloadData(dynuapi))
        RichTextBox1.Text = page
        If RichTextBox1.Text.Contains("nochg") Then
            MsgBox("Your Host doesn't need changes.", MsgBoxStyle.Information)
        ElseIf RichTextBox1.Text.Contains("good") Then
            MsgBox("Your Host has been updated.", MsgBoxStyle.Information)
        ElseIf RichTextBox1.Text.Contains("badauth") Then
            MsgBox("Error, Your username or password or Hostname is incorrect", MsgBoxStyle.Critical, "Error")
        End If
    End Sub
    Private Function GetMyIP() As String
        Dim GetIp As New WebClient
        Dim b As String = GetIp.DownloadString("https://api.ipify.org/")
        Return b
    End Function
    Function md5hash()
        Dim Bytes() As Byte
        Dim sb As New StringBuilder()
        Bytes = Encoding.Default.GetBytes(TextBox3.Text)
        Bytes = MD5.Create().ComputeHash(Bytes)
        For x As Integer = 0 To Bytes.Length - 1
            sb.Append(Bytes(x).ToString("x2"))
        Next
        Return sb.ToString()
    End Function
    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Not myip = GetMyIP() Then
            Dim dynuapi As String = "http://api.dynu.com/nic/update?username=" & TextBox2.Text & "&password=" & md5hash() & "&mydomain=" & TextBox1.Text & "&myip=" & myip
            Dim wc = New Net.WebClient()
            Dim utf8 = New UTF8Encoding
            Dim page As String = utf8.GetString(wc.DownloadData(dynuapi))
            RichTextBox1.Text = page
            If RichTextBox1.Text.Contains("nochg") Then
                '        MsgBox("Your Host doesn't need changes.", MsgBoxStyle.Information)
            ElseIf RichTextBox1.Text.Contains("good") Then
                '    MsgBox("Your Host has been updated.", MsgBoxStyle.Information)
            ElseIf RichTextBox1.Text.Contains("badauth") Then
                '  MsgBox("Error, Your username or password or Hostname is incorrect", MsgBoxStyle.Critical, "Error")
            End If
        Else

        End If
    End Sub
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "[ Start Automatic Updator ]" Then
            Timer1.Start()
            Button2.Text = "[ Stop Automatic Updator ]"
            Me.Hide()
        ElseIf Button2.Text = "[ Stop Automatic Updator ]" Then
            Timer1.Stop()
            Button2.Text = "[ Start Automatic Updator ]"
        End If
    End Sub
End Class