﻿Public Class ConPro
    Dim x, y As Integer
    Private Sub ConPro_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.cpstatus = True Then
            Me.Opacity = 0
            Me.Hide()
            Me.Close()
            Timer1.Stop()
        End If
        Me.Button1.Select()
        x = Screen.PrimaryScreen.WorkingArea.Width - Me.Width
        y = Screen.PrimaryScreen.WorkingArea.Height
        Me.Location = New Point(x, y)
        Me.TopMost = True
        Timer1.Start()
        '      My.Computer.Audio.Play(My.Resources.sound, AudioPlayMode.Background)
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        If Not y <= Screen.PrimaryScreen.WorkingArea.Height - Me.Height Then
            y -= 5
            Me.Location = New Point(x, y)
        Else

        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If CheckBox1.Checked = True Then
            My.Settings.cpstatus = True
            My.Settings.Save()
            Me.Close()
        Else
            Me.Close()
        End If
    End Sub
End Class