﻿Imports System.Text
Imports System.Xml
Imports System.Configuration
Imports System.Reflection
Imports System.Net

Public Class Form6
    Dim myip As String = GetMyIP()
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim wc = New Net.WebClient()
        Dim utf8 = New UTF8Encoding

        Dim page As String = utf8.GetString(wc.DownloadData("https://dynupdate.no-ip.com/dns?username=" & TextBox2.Text & "&password=" & TextBox3.Text & "&hostname=" & TextBox1.Text))
        Dim texter() As String = page.Split(":")
        RichTextBox1.Text = texter(1)
        If texter(1).Contains("0") Then
            MsgBox("Success - IP address is current, no update performed", MsgBoxStyle.Information)
        End If
        If texter(1).Contains("1") Then
            MsgBox("Success - DNS hostname update successful", MsgBoxStyle.Information)
        End If
        If texter(1).Contains("2") Then

            MsgBox("Error - Hostname supplied does not exist", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("3") Then
            MsgBox("Error - Invalid username", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("4") Then
            MsgBox("Error - Invalid password", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("5") Then
            MsgBox("Error - Too many updates sent. Updates are blocked   until 1 hour passes since last status of 5 returned.", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("6") Then
            MsgBox("Error - Account disabled due to violation of No-IP   terms of service. Our terms of service can be viewed at   http://www.no-ip.com/legal/tos", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("7") Then
            MsgBox("Error - Invalid IP. Invalid IP submitted is   improperly formated, is a private LAN RFC 1918 address, or an abuse   blacklisted address.", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("8") Then
            MsgBox("Error - Disabled / Locked hostname", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("9") Then
            MsgBox("Host updated is configured as a web redirect and no update was performed.", MsgBoxStyle.Information)
        End If
        If texter(1).Contains("10") Then
            MsgBox("Error - Group supplied does not exist", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("11") Then
            MsgBox("Success - DNS group update is successful", MsgBoxStyle.Information)
        End If
        If texter(1).Contains("12") Then
            MsgBox("Success - DNS group is current, no update performed.", MsgBoxStyle.Information)
        End If
        If texter(1).Contains("13") Then
            MsgBox("Error - Update client support not available for supplied hostname or group", MsgBoxStyle.Critical)

        End If
        If texter(1).Contains("14") Then
            MsgBox("Error - Hostname supplied does not have offline   settings configured. Returned if sending offline=YES on a host that  does  not have any offline actions configured.", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("99") Then
            MsgBox("Error - Client disabled. Client should exit and not   perform any more updates without user intervention.", MsgBoxStyle.Critical)
        End If
        If texter(1).Contains("100") Then
            MsgBox("Error - User input error usually returned if missing required request parameters", MsgBoxStyle.Critical)
        End If
    End Sub

    Private Function GetMyIP() As String
        Dim GetIp As New WebClient
        Dim b As String = GetIp.DownloadString("https://api.ipify.org/")
        Return b
    End Function

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Dim wc = New Net.WebClient()
        Dim utf8 = New UTF8Encoding
        If Not GetMyIP() = myip Then
            Dim page As String = utf8.GetString(wc.DownloadData("https://dynupdate.no-ip.com/dns?username=" & TextBox2.Text & "&password=" & TextBox3.Text & "&hostname=" & TextBox1.Text))
            Dim texter() As String = page.Split(":")
            RichTextBox1.Text = texter(1)
            If texter(1).Contains("0") Then
                '  MsgBox("Success - IP address is current, no update performed", MsgBoxStyle.Information)
            End If
            If texter(1).Contains("1") Then
                '         MsgBox("Success - DNS hostname update successful", MsgBoxStyle.Information)
            End If
            If texter(1).Contains("2") Then

                '    MsgBox("Error - Hostname supplied does not exist", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("3") Then
                '  MsgBox("Error - Invalid username", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("4") Then
                ' MsgBox("Error - Invalid password", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("5") Then
                '  MsgBox("Error - Too many updates sent. Updates are blocked   until 1 hour passes since last status of 5 returned.", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("6") Then
                'MsgBox("Error - Account disabled due to violation of No-IP   terms of service. Our terms of service can be viewed at   http://www.no-ip.com/legal/tos", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("7") Then
                '  MsgBox("Error - Invalid IP. Invalid IP submitted is   improperly formated, is a private LAN RFC 1918 address, or an abuse   blacklisted address.", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("8") Then
                '  MsgBox("Error - Disabled / Locked hostname", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("9") Then
                '  MsgBox("Host updated is configured as a web redirect and no update was performed.", MsgBoxStyle.Information)
            End If
            If texter(1).Contains("10") Then
                ' MsgBox("Error - Group supplied does not exist", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("11") Then
                '    MsgBox("Success - DNS group update is successful", MsgBoxStyle.Information)
            End If
            If texter(1).Contains("12") Then
                '   MsgBox("Success - DNS group is current, no update performed.", MsgBoxStyle.Information)
            End If
            If texter(1).Contains("13") Then
                '   MsgBox("Error - Update client support not available for supplied hostname or group", MsgBoxStyle.Critical)

            End If
            If texter(1).Contains("14") Then
                '   MsgBox("Error - Hostname supplied does not have offline   settings configured. Returned if sending offline=YES on a host that  does  not have any offline actions configured.", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("99") Then
                '   MsgBox("Error - Client disabled. Client should exit and not   perform any more updates without user intervention.", MsgBoxStyle.Critical)
            End If
            If texter(1).Contains("100") Then
                '  MsgBox("Error - User input error usually returned if missing required request parameters", MsgBoxStyle.Critical)
            End If
        End If
        
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        If Button2.Text = "[ Start Automatic Updator ]" Then
            Timer1.Start()
            Button2.Text = "[ Stop Automatic Updator ]"
            Me.Hide()
        ElseIf Button2.Text = "[ Stop Automatic Updator ]" Then
            Timer1.Stop()
            Button2.Text = "[ Start Automatic Updator ]"
        End If
    End Sub
End Class