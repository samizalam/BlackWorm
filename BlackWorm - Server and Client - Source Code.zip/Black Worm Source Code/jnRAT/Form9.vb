﻿Public Class Form9
    Public buttontimer As Integer = 0
    Public timer As System.Threading.Thread

    Private Sub Form9_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        End
        Application.Exit()
    End Sub
    Private Sub Form9_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If My.Settings.nostart = True Then
            Me.Opacity = 0
            Me.Hide()
            Me.Visible = False
            PortSettings.Show()
            Timer1.Start()
            Me.Hide()
            Me.Visible = False
        Else

        End If
        Button1.Select()
        buttontimer = 0
        timer = New System.Threading.Thread(AddressOf buttonNumber)
        timer.IsBackground = True
        timer.Start()
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        My.Settings.Terms = True
        My.Settings.Save()
        Me.Hide()
        Me.Visible = False
        Me.Opacity = 0
        If My.Settings.SettingsNoStart = True Then
            Form1.Show()
        Else
            PortSettings.Show()
        End If
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Me.Opacity = 0
        Me.Hide()
        Me.Visible = False
    End Sub

    Private Sub CheckBox1_CheckedChanged(sender As Object, e As EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            My.Settings.nostart = True
            My.Settings.Save()
        End If
    End Sub
    Private Sub buttonNumber()
        On Error Resume Next
        Dim st As Integer = +1
        Dim i As Integer = 10
        If st <> 2 Then
bypass:
            System.Threading.Thread.Sleep(950)
            Button1.Text = "Agree " & "[ " & i & " ]"
            If i = 0 Then
                Button1.Text = "Agree"
                Button1.Enabled = True
                Exit Sub
            End If
            i = i - 1
            Resume bypass
        End If
    End Sub
End Class