﻿Imports System.Text.RegularExpressions
Imports System.Linq
Public Class GroupManager
    Private Sub GroupManager_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        For Each g As String In IO.File.ReadAllLines("Groups.ini")
            Lv1.Items.Add(g.Replace("<Group>", "").Replace("</Group>", ""))
        Next
    End Sub
    Private Sub AddGroupToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AddGroupToolStripMenuItem.Click
        Dim input As String = InputBox("Please Write The Group Name", "Add Group", "[ Name ]")
        If input = "" Then
            Exit Sub
        Else
            Dim a As New IO.FileInfo("Groups.ini")
            Lv1.Items.Add(input)
            If a.Length = 0 Then
                IO.File.AppendAllText("Groups.ini", "<Group>" & input & "</Group>")
            Else
                IO.File.AppendAllText("Groups.ini", vbNewLine & "<Group>" & input & "</Group>")
            End If
            Dim linesToRemove = {vbNewLine}
            Dim lines = IO.File.ReadAllLines("Groups.ini").Where(Function(line) line <> String.Empty AndAlso Not linesToRemove.Contains(line)).ToArray()
            IO.File.WriteAllLines("Groups.ini", lines)
            If Lv1.Items.Count = 0 Then
                Form1.L1.Groups.Add(Lv1.Items.Count, input)
            Else
                Form1.L1.Groups.Add(Lv1.Items.Count - 1, input)
            End If
        End If
    End Sub

    Private Sub RemoveGroupToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveGroupToolStripMenuItem.Click
        Try
            For Each c As ListViewItem In Lv1.SelectedItems
                Dim linesToRemove = {vbNewLine, "<Group>" & c.Text & "</Group>"}
                Dim lines = IO.File.ReadAllLines("Groups.ini").Where(Function(line) line <> String.Empty AndAlso Not linesToRemove.Contains(line)).ToArray()
                IO.File.WriteAllLines("Groups.ini", lines)
                For Each b As ListViewItem In Form1.L1.Groups(c.Index).Items
                    Form1.S.Send(b.Tag, Form1.ENB("aGroup") & Form1.Y & "None")
                Next
                Try
                    Form1.L1.Groups(c.Index).Items.Clear()
                    Form1.L1.Groups.RemoveAt(c.Index)
                Catch
                    Form1.L1.Groups.RemoveAt(c.Index)
                End Try
                Lv1.Items.Remove(c)
            Next
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class