﻿Public Class ClassName
    Public Function BlackPlugin()
        MsgBox("Hello World")
    End Function




End Class
