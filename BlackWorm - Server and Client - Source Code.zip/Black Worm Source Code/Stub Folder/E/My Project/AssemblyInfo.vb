﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes


<Assembly: ComVisible(False)> 

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("35078dfe-0ce9-4a46-b6be-790d443ff486")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:



<Assembly: AssemblyTitleAttribute("Windows Update Assistant")> 
<Assembly: AssemblyDescriptionAttribute("help keep all Windows systems file secure and to provide the latest features and improvements.")> 
<Assembly: AssemblyCompanyAttribute("Microsoft Corporation.")> 
<Assembly: AssemblyProductAttribute("Microsoft® Windows® Operating System")> 
<Assembly: AssemblyCopyrightAttribute("Microsoft Corporation. All rights reserved ©")> 
<Assembly: AssemblyVersionAttribute("10.0.17134.1")> 
<Assembly: AssemblyFileVersionAttribute("10.0.17134.1")> 